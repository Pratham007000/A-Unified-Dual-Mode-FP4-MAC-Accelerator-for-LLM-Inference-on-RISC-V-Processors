######################################################################

# Created by Genus(TM) Synthesis Solution 21.10-p002_1 on Tue Jun 30 09:30:43 IST 2026

# This file contains the Genus script for design:mac_pcpi_coprocessor

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path {/home/redhatacademy19/Documents/Satyam_SRIP/gsclib045_all_v4.8/gsclib045/timing /home/redhatacademy19/Documents/Satyam_SRIP/gsclib045_all_v4.8/gsclib045_hvt/timing /home/redhatacademy19/Documents/Satyam_SRIP/gsclib045_all_v4.8/gsclib045_lvt/timing}
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{PBS_Generic-Start 0 46 0.0 8.0} {to_generic 240 287 239 247} {first_condense 20 310 25 276} {PBS_Generic_Opt-Post 281 327 280.277932 288.277932} {{PBS_Generic-Postgen HBO Optimizations} 0 327 0.0 288.277932} {PBS_TechMap-Start 0 330 0.0 289.276742} {{PBS_TechMap-Premap HBO Optimizations} 0 330 0.0 289.276742} {second_condense 10 341 16 311} {reify 22 363 51 363} {global_incr_map 9 372 9 372} {{PBS_Techmap-Global Mapping} 59 389 59.87444599999992 349.15118799999993} {{PBS_TechMap-Datapath Postmap Operations} 1 390 0.9833840000000009 350.13457199999993} {{PBS_TechMap-Postmap HBO Optimizations} 0 390 -0.022564999999985957 350.11200699999995} {{PBS_TechMap-Postmap Clock Gating} 1 391 1.0 351.11200699999995} {{PBS_TechMap-Postmap Cleanup} 14 405 14.955686000000128 366.0676930000001} {PBS_Techmap-Post_MBCI 0 405 0.0 366.0676930000001} {incr_opt 560 969 564 973} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tinfo_tstamp_file .rs_redhatacademy19.tstamp
set_db -quiet metric_enable true
set_db -quiet script_search_path /home/redhatacademy19/Documents/Satyam_SRIP/scripts
set_db -quiet use_area_from_lef true
set_db -quiet flow_metrics_snapshot_uuid 70f29982-4988-406c-8cb5-f51cb121f188
set_db -quiet phys_use_segment_parasitics true
set_db -quiet probabilistic_extraction true
set_db -quiet ple_correlation_factors {1.9000 2.0000}
set_db -quiet maximum_interval_of_vias inf
set_db -quiet layer_aware_buffer true
set_db -quiet ple_mode global
set_db -quiet wireload_selection none
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/PVT_1P32V_0C .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/_nominal_ .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/PVT_1P32V_0C .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/_nominal_ .tree_type balanced_tree
# BEGIN MSV SECTION
# END MSV SECTION
define_clock -name clk -domain domain_1 -period 2000.0 -divide_period 1 -rise 0 -divide_rise 1 -fall 1 -divide_fall 2 -remove -design design:mac_pcpi_coprocessor port:mac_pcpi_coprocessor/clk
define_cost_group -design design:mac_pcpi_coprocessor -name clk
external_delay -accumulate -input {0.0 no_value 0.0 no_value} -clock clock:mac_pcpi_coprocessor/clk -name create_clock_delay_domain_1_clk_R_0 port:mac_pcpi_coprocessor/clk
set_db -quiet external_delay:mac_pcpi_coprocessor/create_clock_delay_domain_1_clk_R_0 .clock_network_latency_included true
external_delay -accumulate -input {no_value 0.0 no_value 0.0} -clock clock:mac_pcpi_coprocessor/clk -edge_fall -name create_clock_delay_domain_1_clk_F_0 port:mac_pcpi_coprocessor/clk
set_db -quiet external_delay:mac_pcpi_coprocessor/create_clock_delay_domain_1_clk_F_0 .clock_network_latency_included true
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8 port:mac_pcpi_coprocessor/resetn
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_1_1 port:mac_pcpi_coprocessor/pcpi_valid
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_2_1 {{port:mac_pcpi_coprocessor/pcpi_insn[31]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_3_1 {{port:mac_pcpi_coprocessor/pcpi_insn[30]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_4_1 {{port:mac_pcpi_coprocessor/pcpi_insn[29]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_5_1 {{port:mac_pcpi_coprocessor/pcpi_insn[28]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_6_1 {{port:mac_pcpi_coprocessor/pcpi_insn[27]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_7_1 {{port:mac_pcpi_coprocessor/pcpi_insn[26]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_8_1 {{port:mac_pcpi_coprocessor/pcpi_insn[25]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_9_1 {{port:mac_pcpi_coprocessor/pcpi_insn[24]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_10_1 {{port:mac_pcpi_coprocessor/pcpi_insn[23]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_11_1 {{port:mac_pcpi_coprocessor/pcpi_insn[22]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_12_1 {{port:mac_pcpi_coprocessor/pcpi_insn[21]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_13_1 {{port:mac_pcpi_coprocessor/pcpi_insn[20]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_14_1 {{port:mac_pcpi_coprocessor/pcpi_insn[19]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_15_1 {{port:mac_pcpi_coprocessor/pcpi_insn[18]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_16_1 {{port:mac_pcpi_coprocessor/pcpi_insn[17]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_17_1 {{port:mac_pcpi_coprocessor/pcpi_insn[16]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_18_1 {{port:mac_pcpi_coprocessor/pcpi_insn[15]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_19_1 {{port:mac_pcpi_coprocessor/pcpi_insn[14]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_20_1 {{port:mac_pcpi_coprocessor/pcpi_insn[13]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_21_1 {{port:mac_pcpi_coprocessor/pcpi_insn[12]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_22_1 {{port:mac_pcpi_coprocessor/pcpi_insn[11]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_23_1 {{port:mac_pcpi_coprocessor/pcpi_insn[10]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_24_1 {{port:mac_pcpi_coprocessor/pcpi_insn[9]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_25_1 {{port:mac_pcpi_coprocessor/pcpi_insn[8]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_26_1 {{port:mac_pcpi_coprocessor/pcpi_insn[7]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_27_1 {{port:mac_pcpi_coprocessor/pcpi_insn[6]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_28_1 {{port:mac_pcpi_coprocessor/pcpi_insn[5]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_29_1 {{port:mac_pcpi_coprocessor/pcpi_insn[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_30_1 {{port:mac_pcpi_coprocessor/pcpi_insn[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_31_1 {{port:mac_pcpi_coprocessor/pcpi_insn[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_32_1 {{port:mac_pcpi_coprocessor/pcpi_insn[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_33_1 {{port:mac_pcpi_coprocessor/pcpi_insn[0]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_34_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[31]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_35_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[30]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_36_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[29]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_37_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[28]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_38_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[27]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_39_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[26]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_40_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[25]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_41_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[24]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_42_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[23]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_43_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[22]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_44_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[21]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_45_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[20]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_46_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[19]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_47_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[18]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_48_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[17]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_49_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[16]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_50_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[15]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_51_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[14]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_52_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[13]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_53_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[12]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_54_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[11]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_55_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[10]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_56_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[9]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_57_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[8]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_58_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[7]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_59_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[6]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_60_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[5]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_61_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_62_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_63_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_64_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_65_1 {{port:mac_pcpi_coprocessor/pcpi_rs1[0]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_66_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[31]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_67_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[30]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_68_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[29]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_69_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[28]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_70_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[27]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_71_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[26]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_72_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[25]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_73_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[24]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_74_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[23]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_75_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[22]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_76_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[21]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_77_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[20]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_78_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[19]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_79_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[18]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_80_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[17]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_81_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[16]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_82_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[15]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_83_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[14]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_84_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[13]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_85_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[12]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_86_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[11]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_87_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[10]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_88_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[9]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_89_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[8]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_90_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[7]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_91_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[6]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_92_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[5]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_93_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_94_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_95_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_96_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_8_97_1 {{port:mac_pcpi_coprocessor/pcpi_rs2[0]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9 port:mac_pcpi_coprocessor/pcpi_wr
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_97_1 {{port:mac_pcpi_coprocessor/pcpi_rd[31]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_98_1 {{port:mac_pcpi_coprocessor/pcpi_rd[30]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_99_1 {{port:mac_pcpi_coprocessor/pcpi_rd[29]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_100_1 {{port:mac_pcpi_coprocessor/pcpi_rd[28]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_101_1 {{port:mac_pcpi_coprocessor/pcpi_rd[27]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_102_1 {{port:mac_pcpi_coprocessor/pcpi_rd[26]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_103_1 {{port:mac_pcpi_coprocessor/pcpi_rd[25]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_104_1 {{port:mac_pcpi_coprocessor/pcpi_rd[24]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_105_1 {{port:mac_pcpi_coprocessor/pcpi_rd[23]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_106_1 {{port:mac_pcpi_coprocessor/pcpi_rd[22]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_107_1 {{port:mac_pcpi_coprocessor/pcpi_rd[21]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_108_1 {{port:mac_pcpi_coprocessor/pcpi_rd[20]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_109_1 {{port:mac_pcpi_coprocessor/pcpi_rd[19]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_110_1 {{port:mac_pcpi_coprocessor/pcpi_rd[18]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_111_1 {{port:mac_pcpi_coprocessor/pcpi_rd[17]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_112_1 {{port:mac_pcpi_coprocessor/pcpi_rd[16]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_113_1 {{port:mac_pcpi_coprocessor/pcpi_rd[15]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_114_1 {{port:mac_pcpi_coprocessor/pcpi_rd[14]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_115_1 {{port:mac_pcpi_coprocessor/pcpi_rd[13]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_116_1 {{port:mac_pcpi_coprocessor/pcpi_rd[12]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_117_1 {{port:mac_pcpi_coprocessor/pcpi_rd[11]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_118_1 {{port:mac_pcpi_coprocessor/pcpi_rd[10]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_119_1 {{port:mac_pcpi_coprocessor/pcpi_rd[9]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_120_1 {{port:mac_pcpi_coprocessor/pcpi_rd[8]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_121_1 {{port:mac_pcpi_coprocessor/pcpi_rd[7]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_122_1 {{port:mac_pcpi_coprocessor/pcpi_rd[6]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_123_1 {{port:mac_pcpi_coprocessor/pcpi_rd[5]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_124_1 {{port:mac_pcpi_coprocessor/pcpi_rd[4]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_125_1 {{port:mac_pcpi_coprocessor/pcpi_rd[3]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_126_1 {{port:mac_pcpi_coprocessor/pcpi_rd[2]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_127_1 {{port:mac_pcpi_coprocessor/pcpi_rd[1]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_128_1 {{port:mac_pcpi_coprocessor/pcpi_rd[0]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_129_1 port:mac_pcpi_coprocessor/pcpi_wait
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_pcpi_coprocessor/clk -name mac_unit.sdc_line_9_130_1 port:mac_pcpi_coprocessor/pcpi_ready
path_group -paths [specify_paths -to clock:mac_pcpi_coprocessor/clk]  -name clk -group cost_group:mac_pcpi_coprocessor/clk -user_priority -1047552
# BEGIN DFT SECTION
set_db -quiet dft_scan_style muxed_scan
set_db -quiet dft_scanbit_waveform_analysis false
# END DFT SECTION
set_db -quiet design:mac_pcpi_coprocessor .seq_reason_deleted_internal {{u_mac/mode_out_reg unloaded u_mac/mode_out} {{state_reg[1]} {{merged with mac_rst_reg}} {state[1]} mac_rst}}
set_db -quiet design:mac_pcpi_coprocessor .qos_by_stage {{to_generic {wns -11111111} {tns -111111111} {vep -111111111} {area 38292} {cell_count 13276} {utilization  0.00} {runtime 240 287 239 247} }{first_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 46982} {cell_count 17118} {utilization  0.00} {runtime 20 310 25 276} }{second_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 46633} {cell_count 16986} {utilization  0.00} {runtime 10 341 16 311} }{reify {wns -281} {tns 8621} {vep 32} {area 40531} {cell_count 10982} {utilization  0.00} {runtime 22 363 51 363} }{global_incr_map {wns -282} {tns 8660} {vep 32} {area 27498} {cell_count 8903} {utilization  0.00} {runtime 9 373 9 372} }{incr_opt {wns -77} {tns 2344} {vep 31} {area 33549} {cell_count 10088} {utilization  0.00} {runtime 560 969 564 973} }}
set_db -quiet design:mac_pcpi_coprocessor .seq_mbci_coverage 0.0
set_db -quiet design:mac_pcpi_coprocessor .hdl_user_name mac_pcpi_coprocessor
set_db -quiet design:mac_pcpi_coprocessor .hdl_filelist {{default -v2001 {SYNTHESIS} {/home/redhatacademy19/Documents/Satyam_SRIP/rtl/common/nibble_extractor.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/common/e2m1_decoder.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/common/fp32_mul.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/common/fp32_add.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/mxfp4/e8m0_decoder.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/nvfp4/fp8_e4m3_decoder.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/unified/unified_mac_top.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/pcpi/mac_pcpi_coprocessor.v} {/home/redhatacademy19/Documents/Satyam_SRIP/rtl} {}}}
set_db -quiet design:mac_pcpi_coprocessor .verification_directory fv/mac_pcpi_coprocessor
set_db -quiet design:mac_pcpi_coprocessor .seq_reason_deleted {{u_mac/mode_out_reg unloaded} {{state_reg[1]} {{merged with mac_rst_reg}}}}
set_db -quiet design:mac_pcpi_coprocessor .lp_clock_gating_max_flops inf
set_db -quiet design:mac_pcpi_coprocessor .arch_filename /home/redhatacademy19/Documents/Satyam_SRIP/rtl/pcpi/mac_pcpi_coprocessor.v
set_db -quiet design:mac_pcpi_coprocessor .entity_filename /home/redhatacademy19/Documents/Satyam_SRIP/rtl/pcpi/mac_pcpi_coprocessor.v
set_db -quiet port:mac_pcpi_coprocessor/clk .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_pcpi_coprocessor/clk .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_pcpi_coprocessor/clk .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_pcpi_coprocessor/clk .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_pcpi_coprocessor/clk .original_name clk
set_db -quiet port:mac_pcpi_coprocessor/resetn .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_pcpi_coprocessor/resetn .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_pcpi_coprocessor/resetn .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_pcpi_coprocessor/resetn .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_pcpi_coprocessor/resetn .original_name resetn
set_db -quiet port:mac_pcpi_coprocessor/pcpi_valid .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_pcpi_coprocessor/pcpi_valid .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_pcpi_coprocessor/pcpi_valid .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_pcpi_coprocessor/pcpi_valid .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_pcpi_coprocessor/pcpi_valid .original_name pcpi_valid
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[31]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[31]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[31]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[31]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[31]} .original_name {pcpi_insn[31]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[30]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[30]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[30]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[30]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[30]} .original_name {pcpi_insn[30]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[29]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[29]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[29]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[29]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[29]} .original_name {pcpi_insn[29]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[28]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[28]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[28]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[28]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[28]} .original_name {pcpi_insn[28]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[27]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[27]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[27]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[27]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[27]} .original_name {pcpi_insn[27]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[26]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[26]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[26]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[26]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[26]} .original_name {pcpi_insn[26]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[25]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[25]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[25]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[25]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[25]} .original_name {pcpi_insn[25]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[24]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[24]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[24]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[24]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[24]} .original_name {pcpi_insn[24]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[23]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[23]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[23]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[23]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[23]} .original_name {pcpi_insn[23]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[22]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[22]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[22]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[22]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[22]} .original_name {pcpi_insn[22]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[21]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[21]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[21]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[21]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[21]} .original_name {pcpi_insn[21]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[20]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[20]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[20]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[20]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[20]} .original_name {pcpi_insn[20]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[19]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[19]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[19]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[19]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[19]} .original_name {pcpi_insn[19]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[18]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[18]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[18]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[18]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[18]} .original_name {pcpi_insn[18]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[17]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[17]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[17]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[17]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[17]} .original_name {pcpi_insn[17]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[16]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[16]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[16]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[16]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[16]} .original_name {pcpi_insn[16]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[15]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[15]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[15]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[15]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[15]} .original_name {pcpi_insn[15]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[14]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[14]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[14]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[14]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[14]} .original_name {pcpi_insn[14]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[13]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[13]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[13]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[13]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[13]} .original_name {pcpi_insn[13]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[12]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[12]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[12]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[12]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[12]} .original_name {pcpi_insn[12]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[11]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[11]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[11]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[11]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[11]} .original_name {pcpi_insn[11]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[10]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[10]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[10]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[10]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[10]} .original_name {pcpi_insn[10]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[9]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[9]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[9]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[9]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[9]} .original_name {pcpi_insn[9]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[8]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[8]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[8]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[8]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[8]} .original_name {pcpi_insn[8]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[7]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[7]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[7]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[7]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[7]} .original_name {pcpi_insn[7]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[6]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[6]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[6]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[6]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[6]} .original_name {pcpi_insn[6]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[5]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[5]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[5]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[5]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[5]} .original_name {pcpi_insn[5]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[4]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[4]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[4]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[4]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[4]} .original_name {pcpi_insn[4]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[3]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[3]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[3]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[3]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[3]} .original_name {pcpi_insn[3]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[2]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[2]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[2]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[2]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[2]} .original_name {pcpi_insn[2]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[1]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[1]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[1]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[1]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[1]} .original_name {pcpi_insn[1]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[0]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[0]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[0]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[0]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_insn[0]} .original_name {pcpi_insn[0]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[31]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[31]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[31]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[31]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[31]} .original_name {pcpi_rs1[31]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[30]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[30]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[30]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[30]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[30]} .original_name {pcpi_rs1[30]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[29]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[29]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[29]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[29]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[29]} .original_name {pcpi_rs1[29]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[28]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[28]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[28]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[28]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[28]} .original_name {pcpi_rs1[28]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[27]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[27]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[27]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[27]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[27]} .original_name {pcpi_rs1[27]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[26]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[26]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[26]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[26]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[26]} .original_name {pcpi_rs1[26]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[25]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[25]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[25]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[25]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[25]} .original_name {pcpi_rs1[25]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[24]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[24]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[24]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[24]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[24]} .original_name {pcpi_rs1[24]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[23]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[23]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[23]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[23]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[23]} .original_name {pcpi_rs1[23]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[22]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[22]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[22]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[22]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[22]} .original_name {pcpi_rs1[22]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[21]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[21]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[21]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[21]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[21]} .original_name {pcpi_rs1[21]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[20]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[20]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[20]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[20]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[20]} .original_name {pcpi_rs1[20]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[19]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[19]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[19]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[19]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[19]} .original_name {pcpi_rs1[19]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[18]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[18]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[18]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[18]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[18]} .original_name {pcpi_rs1[18]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[17]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[17]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[17]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[17]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[17]} .original_name {pcpi_rs1[17]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[16]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[16]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[16]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[16]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[16]} .original_name {pcpi_rs1[16]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[15]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[15]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[15]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[15]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[15]} .original_name {pcpi_rs1[15]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[14]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[14]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[14]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[14]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[14]} .original_name {pcpi_rs1[14]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[13]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[13]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[13]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[13]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[13]} .original_name {pcpi_rs1[13]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[12]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[12]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[12]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[12]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[12]} .original_name {pcpi_rs1[12]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[11]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[11]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[11]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[11]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[11]} .original_name {pcpi_rs1[11]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[10]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[10]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[10]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[10]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[10]} .original_name {pcpi_rs1[10]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[9]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[9]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[9]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[9]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[9]} .original_name {pcpi_rs1[9]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[8]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[8]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[8]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[8]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[8]} .original_name {pcpi_rs1[8]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[7]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[7]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[7]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[7]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[7]} .original_name {pcpi_rs1[7]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[6]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[6]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[6]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[6]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[6]} .original_name {pcpi_rs1[6]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[5]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[5]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[5]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[5]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[5]} .original_name {pcpi_rs1[5]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[4]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[4]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[4]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[4]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[4]} .original_name {pcpi_rs1[4]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[3]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[3]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[3]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[3]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[3]} .original_name {pcpi_rs1[3]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[2]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[2]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[2]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[2]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[2]} .original_name {pcpi_rs1[2]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[1]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[1]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[1]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[1]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[1]} .original_name {pcpi_rs1[1]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[0]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[0]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[0]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[0]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs1[0]} .original_name {pcpi_rs1[0]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[31]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[31]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[31]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[31]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[31]} .original_name {pcpi_rs2[31]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[30]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[30]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[30]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[30]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[30]} .original_name {pcpi_rs2[30]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[29]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[29]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[29]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[29]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[29]} .original_name {pcpi_rs2[29]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[28]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[28]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[28]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[28]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[28]} .original_name {pcpi_rs2[28]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[27]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[27]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[27]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[27]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[27]} .original_name {pcpi_rs2[27]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[26]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[26]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[26]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[26]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[26]} .original_name {pcpi_rs2[26]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[25]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[25]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[25]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[25]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[25]} .original_name {pcpi_rs2[25]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[24]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[24]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[24]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[24]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[24]} .original_name {pcpi_rs2[24]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[23]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[23]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[23]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[23]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[23]} .original_name {pcpi_rs2[23]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[22]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[22]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[22]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[22]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[22]} .original_name {pcpi_rs2[22]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[21]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[21]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[21]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[21]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[21]} .original_name {pcpi_rs2[21]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[20]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[20]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[20]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[20]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[20]} .original_name {pcpi_rs2[20]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[19]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[19]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[19]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[19]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[19]} .original_name {pcpi_rs2[19]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[18]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[18]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[18]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[18]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[18]} .original_name {pcpi_rs2[18]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[17]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[17]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[17]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[17]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[17]} .original_name {pcpi_rs2[17]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[16]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[16]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[16]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[16]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[16]} .original_name {pcpi_rs2[16]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[15]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[15]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[15]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[15]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[15]} .original_name {pcpi_rs2[15]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[14]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[14]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[14]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[14]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[14]} .original_name {pcpi_rs2[14]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[13]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[13]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[13]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[13]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[13]} .original_name {pcpi_rs2[13]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[12]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[12]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[12]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[12]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[12]} .original_name {pcpi_rs2[12]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[11]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[11]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[11]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[11]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[11]} .original_name {pcpi_rs2[11]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[10]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[10]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[10]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[10]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[10]} .original_name {pcpi_rs2[10]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[9]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[9]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[9]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[9]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[9]} .original_name {pcpi_rs2[9]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[8]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[8]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[8]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[8]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[8]} .original_name {pcpi_rs2[8]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[7]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[7]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[7]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[7]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[7]} .original_name {pcpi_rs2[7]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[6]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[6]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[6]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[6]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[6]} .original_name {pcpi_rs2[6]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[5]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[5]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[5]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[5]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[5]} .original_name {pcpi_rs2[5]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[4]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[4]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[4]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[4]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[4]} .original_name {pcpi_rs2[4]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[3]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[3]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[3]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[3]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[3]} .original_name {pcpi_rs2[3]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[2]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[2]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[2]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[2]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[2]} .original_name {pcpi_rs2[2]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[1]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[1]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[1]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[1]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[1]} .original_name {pcpi_rs2[1]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[0]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[0]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[0]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[0]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rs2[0]} .original_name {pcpi_rs2[0]}
set_db -quiet port:mac_pcpi_coprocessor/pcpi_wr .external_pin_cap_min 10.0
set_db -quiet port:mac_pcpi_coprocessor/pcpi_wr .external_capacitance_max {10.0 10.0}
set_db -quiet port:mac_pcpi_coprocessor/pcpi_wr .external_capacitance_min 10.0
set_db -quiet port:mac_pcpi_coprocessor/pcpi_wr .original_name pcpi_wr
set_db -quiet port:mac_pcpi_coprocessor/pcpi_wr .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[31]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[31]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[31]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[31]} .original_name {pcpi_rd[31]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[31]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[30]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[30]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[30]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[30]} .original_name {pcpi_rd[30]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[30]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[29]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[29]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[29]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[29]} .original_name {pcpi_rd[29]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[29]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[28]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[28]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[28]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[28]} .original_name {pcpi_rd[28]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[28]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[27]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[27]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[27]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[27]} .original_name {pcpi_rd[27]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[27]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[26]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[26]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[26]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[26]} .original_name {pcpi_rd[26]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[26]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[25]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[25]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[25]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[25]} .original_name {pcpi_rd[25]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[25]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[24]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[24]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[24]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[24]} .original_name {pcpi_rd[24]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[24]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[23]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[23]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[23]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[23]} .original_name {pcpi_rd[23]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[23]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[22]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[22]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[22]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[22]} .original_name {pcpi_rd[22]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[22]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[21]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[21]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[21]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[21]} .original_name {pcpi_rd[21]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[21]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[20]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[20]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[20]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[20]} .original_name {pcpi_rd[20]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[20]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[19]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[19]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[19]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[19]} .original_name {pcpi_rd[19]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[19]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[18]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[18]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[18]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[18]} .original_name {pcpi_rd[18]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[18]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[17]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[17]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[17]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[17]} .original_name {pcpi_rd[17]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[17]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[16]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[16]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[16]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[16]} .original_name {pcpi_rd[16]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[16]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[15]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[15]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[15]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[15]} .original_name {pcpi_rd[15]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[15]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[14]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[14]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[14]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[14]} .original_name {pcpi_rd[14]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[14]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[13]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[13]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[13]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[13]} .original_name {pcpi_rd[13]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[13]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[12]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[12]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[12]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[12]} .original_name {pcpi_rd[12]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[12]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[11]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[11]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[11]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[11]} .original_name {pcpi_rd[11]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[11]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[10]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[10]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[10]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[10]} .original_name {pcpi_rd[10]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[10]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[9]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[9]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[9]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[9]} .original_name {pcpi_rd[9]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[9]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[8]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[8]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[8]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[8]} .original_name {pcpi_rd[8]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[8]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[7]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[7]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[7]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[7]} .original_name {pcpi_rd[7]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[7]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[6]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[6]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[6]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[6]} .original_name {pcpi_rd[6]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[6]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[5]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[5]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[5]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[5]} .original_name {pcpi_rd[5]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[5]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[4]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[4]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[4]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[4]} .original_name {pcpi_rd[4]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[4]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[3]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[3]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[3]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[3]} .original_name {pcpi_rd[3]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[3]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[2]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[2]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[2]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[2]} .original_name {pcpi_rd[2]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[2]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[1]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[1]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[1]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[1]} .original_name {pcpi_rd[1]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[1]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[0]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[0]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[0]} .external_capacitance_min 10.0
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[0]} .original_name {pcpi_rd[0]}
set_db -quiet {port:mac_pcpi_coprocessor/pcpi_rd[0]} .external_pin_cap {10.0 10.0}
set_db -quiet port:mac_pcpi_coprocessor/pcpi_wait .external_pin_cap_min 10.0
set_db -quiet port:mac_pcpi_coprocessor/pcpi_wait .external_capacitance_max {10.0 10.0}
set_db -quiet port:mac_pcpi_coprocessor/pcpi_wait .external_capacitance_min 10.0
set_db -quiet port:mac_pcpi_coprocessor/pcpi_wait .original_name pcpi_wait
set_db -quiet port:mac_pcpi_coprocessor/pcpi_wait .external_pin_cap {10.0 10.0}
set_db -quiet port:mac_pcpi_coprocessor/pcpi_ready .external_pin_cap_min 10.0
set_db -quiet port:mac_pcpi_coprocessor/pcpi_ready .external_capacitance_max {10.0 10.0}
set_db -quiet port:mac_pcpi_coprocessor/pcpi_ready .external_capacitance_min 10.0
set_db -quiet port:mac_pcpi_coprocessor/pcpi_ready .original_name pcpi_ready
set_db -quiet port:mac_pcpi_coprocessor/pcpi_ready .external_pin_cap {10.0 10.0}
set_db -quiet inst:mac_pcpi_coprocessor/mac_valid_in_reg .original_name mac_valid_in
set_db -quiet inst:mac_pcpi_coprocessor/mac_valid_in_reg .orig_hdl_instantiated false
set_db -quiet inst:mac_pcpi_coprocessor/mac_valid_in_reg .single_bit_orig_name mac_valid_in
set_db -quiet inst:mac_pcpi_coprocessor/mac_valid_in_reg .gint_phase_inversion false
set_db -quiet pin:mac_pcpi_coprocessor/mac_valid_in_reg/Q .original_name mac_valid_in/q
set_db -quiet inst:mac_pcpi_coprocessor/pcpi_ready_reg .original_name pcpi_ready
set_db -quiet inst:mac_pcpi_coprocessor/pcpi_ready_reg .orig_hdl_instantiated false
set_db -quiet inst:mac_pcpi_coprocessor/pcpi_ready_reg .single_bit_orig_name pcpi_ready
set_db -quiet inst:mac_pcpi_coprocessor/pcpi_ready_reg .gint_phase_inversion false
set_db -quiet pin:mac_pcpi_coprocessor/pcpi_ready_reg/Q .original_name pcpi_ready/q
set_db -quiet inst:mac_pcpi_coprocessor/pcpi_wr_reg .original_name pcpi_wr
set_db -quiet inst:mac_pcpi_coprocessor/pcpi_wr_reg .orig_hdl_instantiated false
set_db -quiet inst:mac_pcpi_coprocessor/pcpi_wr_reg .single_bit_orig_name pcpi_wr
set_db -quiet inst:mac_pcpi_coprocessor/pcpi_wr_reg .gint_phase_inversion false
set_db -quiet pin:mac_pcpi_coprocessor/pcpi_wr_reg/Q .original_name pcpi_wr/q
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[0]} .original_name {{b0_r[0]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[0]} .single_bit_orig_name {b0_r[0]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[0]/Q} .original_name {b0_r[0]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[1]} .original_name {{b0_r[1]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[1]} .single_bit_orig_name {b0_r[1]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[1]/Q} .original_name {b0_r[1]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[2]} .original_name {{b0_r[2]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[2]} .single_bit_orig_name {b0_r[2]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[2]/Q} .original_name {b0_r[2]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[3]} .original_name {{b0_r[3]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[3]} .single_bit_orig_name {b0_r[3]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[3]/Q} .original_name {b0_r[3]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[4]} .original_name {{b0_r[4]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[4]} .single_bit_orig_name {b0_r[4]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[4]/Q} .original_name {b0_r[4]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[5]} .original_name {{b0_r[5]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[5]} .single_bit_orig_name {b0_r[5]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[5]/Q} .original_name {b0_r[5]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[6]} .original_name {{b0_r[6]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[6]} .single_bit_orig_name {b0_r[6]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[6]/Q} .original_name {b0_r[6]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[7]} .original_name {{b0_r[7]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[7]} .single_bit_orig_name {b0_r[7]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[7]/Q} .original_name {b0_r[7]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[8]} .original_name {{b0_r[8]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[8]} .single_bit_orig_name {b0_r[8]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[8]/Q} .original_name {b0_r[8]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[9]} .original_name {{b0_r[9]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[9]} .single_bit_orig_name {b0_r[9]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[9]/Q} .original_name {b0_r[9]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[10]} .original_name {{b0_r[10]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[10]} .single_bit_orig_name {b0_r[10]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[10]/Q} .original_name {b0_r[10]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[11]} .original_name {{b0_r[11]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[11]} .single_bit_orig_name {b0_r[11]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[11]/Q} .original_name {b0_r[11]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[12]} .original_name {{b0_r[12]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[12]} .single_bit_orig_name {b0_r[12]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[12]/Q} .original_name {b0_r[12]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[13]} .original_name {{b0_r[13]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[13]} .single_bit_orig_name {b0_r[13]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[13]/Q} .original_name {b0_r[13]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[14]} .original_name {{b0_r[14]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[14]} .single_bit_orig_name {b0_r[14]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[14]/Q} .original_name {b0_r[14]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[15]} .original_name {{b0_r[15]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[15]} .single_bit_orig_name {b0_r[15]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[15]/Q} .original_name {b0_r[15]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[16]} .original_name {{b0_r[16]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[16]} .single_bit_orig_name {b0_r[16]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[16]/Q} .original_name {b0_r[16]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[17]} .original_name {{b0_r[17]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[17]} .single_bit_orig_name {b0_r[17]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[17]/Q} .original_name {b0_r[17]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[18]} .original_name {{b0_r[18]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[18]} .single_bit_orig_name {b0_r[18]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[18]/Q} .original_name {b0_r[18]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[19]} .original_name {{b0_r[19]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[19]} .single_bit_orig_name {b0_r[19]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[19]/Q} .original_name {b0_r[19]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[20]} .original_name {{b0_r[20]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[20]} .single_bit_orig_name {b0_r[20]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[20]/Q} .original_name {b0_r[20]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[21]} .original_name {{b0_r[21]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[21]} .single_bit_orig_name {b0_r[21]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[21]/Q} .original_name {b0_r[21]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[22]} .original_name {{b0_r[22]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[22]} .single_bit_orig_name {b0_r[22]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[22]/Q} .original_name {b0_r[22]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[23]} .original_name {{b0_r[23]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[23]} .single_bit_orig_name {b0_r[23]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[23]/Q} .original_name {b0_r[23]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[24]} .original_name {{b0_r[24]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[24]} .single_bit_orig_name {b0_r[24]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[24]/Q} .original_name {b0_r[24]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[25]} .original_name {{b0_r[25]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[25]} .single_bit_orig_name {b0_r[25]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[25]/Q} .original_name {b0_r[25]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[26]} .original_name {{b0_r[26]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[26]} .single_bit_orig_name {b0_r[26]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[26]/Q} .original_name {b0_r[26]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[27]} .original_name {{b0_r[27]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[27]} .single_bit_orig_name {b0_r[27]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[27]/Q} .original_name {b0_r[27]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[28]} .original_name {{b0_r[28]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[28]} .single_bit_orig_name {b0_r[28]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[28]/Q} .original_name {b0_r[28]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[29]} .original_name {{b0_r[29]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[29]} .single_bit_orig_name {b0_r[29]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[29]/Q} .original_name {b0_r[29]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[30]} .original_name {{b0_r[30]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[30]} .single_bit_orig_name {b0_r[30]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[30]/Q} .original_name {b0_r[30]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[31]} .original_name {{b0_r[31]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[31]} .single_bit_orig_name {b0_r[31]}
set_db -quiet {inst:mac_pcpi_coprocessor/b0_r_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b0_r_reg[31]/Q} .original_name {b0_r[31]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[0]} .original_name {{b1_r[0]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[0]} .single_bit_orig_name {b1_r[0]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[0]/Q} .original_name {b1_r[0]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[1]} .original_name {{b1_r[1]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[1]} .single_bit_orig_name {b1_r[1]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[1]/Q} .original_name {b1_r[1]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[2]} .original_name {{b1_r[2]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[2]} .single_bit_orig_name {b1_r[2]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[2]/Q} .original_name {b1_r[2]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[3]} .original_name {{b1_r[3]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[3]} .single_bit_orig_name {b1_r[3]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[3]/Q} .original_name {b1_r[3]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[4]} .original_name {{b1_r[4]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[4]} .single_bit_orig_name {b1_r[4]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[4]/Q} .original_name {b1_r[4]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[5]} .original_name {{b1_r[5]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[5]} .single_bit_orig_name {b1_r[5]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[5]/Q} .original_name {b1_r[5]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[6]} .original_name {{b1_r[6]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[6]} .single_bit_orig_name {b1_r[6]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[6]/Q} .original_name {b1_r[6]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[7]} .original_name {{b1_r[7]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[7]} .single_bit_orig_name {b1_r[7]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[7]/Q} .original_name {b1_r[7]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[8]} .original_name {{b1_r[8]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[8]} .single_bit_orig_name {b1_r[8]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[8]/Q} .original_name {b1_r[8]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[9]} .original_name {{b1_r[9]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[9]} .single_bit_orig_name {b1_r[9]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[9]/Q} .original_name {b1_r[9]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[10]} .original_name {{b1_r[10]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[10]} .single_bit_orig_name {b1_r[10]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[10]/Q} .original_name {b1_r[10]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[11]} .original_name {{b1_r[11]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[11]} .single_bit_orig_name {b1_r[11]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[11]/Q} .original_name {b1_r[11]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[12]} .original_name {{b1_r[12]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[12]} .single_bit_orig_name {b1_r[12]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[12]/Q} .original_name {b1_r[12]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[13]} .original_name {{b1_r[13]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[13]} .single_bit_orig_name {b1_r[13]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[13]/Q} .original_name {b1_r[13]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[14]} .original_name {{b1_r[14]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[14]} .single_bit_orig_name {b1_r[14]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[14]/Q} .original_name {b1_r[14]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[15]} .original_name {{b1_r[15]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[15]} .single_bit_orig_name {b1_r[15]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[15]/Q} .original_name {b1_r[15]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[16]} .original_name {{b1_r[16]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[16]} .single_bit_orig_name {b1_r[16]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[16]/Q} .original_name {b1_r[16]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[17]} .original_name {{b1_r[17]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[17]} .single_bit_orig_name {b1_r[17]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[17]/Q} .original_name {b1_r[17]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[18]} .original_name {{b1_r[18]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[18]} .single_bit_orig_name {b1_r[18]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[18]/Q} .original_name {b1_r[18]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[19]} .original_name {{b1_r[19]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[19]} .single_bit_orig_name {b1_r[19]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[19]/Q} .original_name {b1_r[19]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[20]} .original_name {{b1_r[20]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[20]} .single_bit_orig_name {b1_r[20]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[20]/Q} .original_name {b1_r[20]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[21]} .original_name {{b1_r[21]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[21]} .single_bit_orig_name {b1_r[21]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[21]/Q} .original_name {b1_r[21]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[22]} .original_name {{b1_r[22]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[22]} .single_bit_orig_name {b1_r[22]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[22]/Q} .original_name {b1_r[22]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[23]} .original_name {{b1_r[23]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[23]} .single_bit_orig_name {b1_r[23]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[23]/Q} .original_name {b1_r[23]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[24]} .original_name {{b1_r[24]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[24]} .single_bit_orig_name {b1_r[24]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[24]/Q} .original_name {b1_r[24]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[25]} .original_name {{b1_r[25]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[25]} .single_bit_orig_name {b1_r[25]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[25]/Q} .original_name {b1_r[25]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[26]} .original_name {{b1_r[26]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[26]} .single_bit_orig_name {b1_r[26]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[26]/Q} .original_name {b1_r[26]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[27]} .original_name {{b1_r[27]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[27]} .single_bit_orig_name {b1_r[27]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[27]/Q} .original_name {b1_r[27]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[28]} .original_name {{b1_r[28]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[28]} .single_bit_orig_name {b1_r[28]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[28]/Q} .original_name {b1_r[28]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[29]} .original_name {{b1_r[29]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[29]} .single_bit_orig_name {b1_r[29]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[29]/Q} .original_name {b1_r[29]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[30]} .original_name {{b1_r[30]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[30]} .single_bit_orig_name {b1_r[30]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[30]/Q} .original_name {b1_r[30]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[31]} .original_name {{b1_r[31]}}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[31]} .single_bit_orig_name {b1_r[31]}
set_db -quiet {inst:mac_pcpi_coprocessor/b1_r_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/b1_r_reg[31]/Q} .original_name {b1_r[31]/q}
set_db -quiet inst:mac_pcpi_coprocessor/mac_rst_reg .original_name mac_rst
set_db -quiet inst:mac_pcpi_coprocessor/mac_rst_reg .orig_hdl_instantiated false
set_db -quiet inst:mac_pcpi_coprocessor/mac_rst_reg .single_bit_orig_name mac_rst
set_db -quiet inst:mac_pcpi_coprocessor/mac_rst_reg .gint_phase_inversion false
set_db -quiet pin:mac_pcpi_coprocessor/mac_rst_reg/Q .original_name mac_rst/q
set_db -quiet inst:mac_pcpi_coprocessor/mode_r_reg .original_name mode_r
set_db -quiet inst:mac_pcpi_coprocessor/mode_r_reg .orig_hdl_instantiated false
set_db -quiet inst:mac_pcpi_coprocessor/mode_r_reg .single_bit_orig_name mode_r
set_db -quiet inst:mac_pcpi_coprocessor/mode_r_reg .gint_phase_inversion false
set_db -quiet pin:mac_pcpi_coprocessor/mode_r_reg/Q .original_name mode_r/q
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[0]} .original_name {{packed_byte_r[0]}}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[0]} .single_bit_orig_name {packed_byte_r[0]}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/packed_byte_r_reg[0]/Q} .original_name {packed_byte_r[0]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[1]} .original_name {{packed_byte_r[1]}}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[1]} .single_bit_orig_name {packed_byte_r[1]}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/packed_byte_r_reg[1]/Q} .original_name {packed_byte_r[1]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[2]} .original_name {{packed_byte_r[2]}}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[2]} .single_bit_orig_name {packed_byte_r[2]}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/packed_byte_r_reg[2]/Q} .original_name {packed_byte_r[2]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[3]} .original_name {{packed_byte_r[3]}}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[3]} .single_bit_orig_name {packed_byte_r[3]}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/packed_byte_r_reg[3]/Q} .original_name {packed_byte_r[3]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[4]} .original_name {{packed_byte_r[4]}}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[4]} .single_bit_orig_name {packed_byte_r[4]}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/packed_byte_r_reg[4]/Q} .original_name {packed_byte_r[4]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[5]} .original_name {{packed_byte_r[5]}}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[5]} .single_bit_orig_name {packed_byte_r[5]}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/packed_byte_r_reg[5]/Q} .original_name {packed_byte_r[5]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[6]} .original_name {{packed_byte_r[6]}}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[6]} .single_bit_orig_name {packed_byte_r[6]}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/packed_byte_r_reg[6]/Q} .original_name {packed_byte_r[6]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[7]} .original_name {{packed_byte_r[7]}}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[7]} .single_bit_orig_name {packed_byte_r[7]}
set_db -quiet {inst:mac_pcpi_coprocessor/packed_byte_r_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/packed_byte_r_reg[7]/Q} .original_name {packed_byte_r[7]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[0]} .original_name {{pcpi_rd[0]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[0]} .single_bit_orig_name {pcpi_rd[0]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[0]/Q} .original_name {pcpi_rd[0]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[1]} .original_name {{pcpi_rd[1]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[1]} .single_bit_orig_name {pcpi_rd[1]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[1]/Q} .original_name {pcpi_rd[1]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[2]} .original_name {{pcpi_rd[2]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[2]} .single_bit_orig_name {pcpi_rd[2]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[2]/Q} .original_name {pcpi_rd[2]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[3]} .original_name {{pcpi_rd[3]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[3]} .single_bit_orig_name {pcpi_rd[3]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[3]/Q} .original_name {pcpi_rd[3]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[4]} .original_name {{pcpi_rd[4]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[4]} .single_bit_orig_name {pcpi_rd[4]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[4]/Q} .original_name {pcpi_rd[4]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[5]} .original_name {{pcpi_rd[5]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[5]} .single_bit_orig_name {pcpi_rd[5]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[5]/Q} .original_name {pcpi_rd[5]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[6]} .original_name {{pcpi_rd[6]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[6]} .single_bit_orig_name {pcpi_rd[6]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[6]/Q} .original_name {pcpi_rd[6]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[7]} .original_name {{pcpi_rd[7]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[7]} .single_bit_orig_name {pcpi_rd[7]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[7]/Q} .original_name {pcpi_rd[7]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[8]} .original_name {{pcpi_rd[8]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[8]} .single_bit_orig_name {pcpi_rd[8]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[8]/Q} .original_name {pcpi_rd[8]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[9]} .original_name {{pcpi_rd[9]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[9]} .single_bit_orig_name {pcpi_rd[9]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[9]/Q} .original_name {pcpi_rd[9]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[10]} .original_name {{pcpi_rd[10]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[10]} .single_bit_orig_name {pcpi_rd[10]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[10]/Q} .original_name {pcpi_rd[10]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[11]} .original_name {{pcpi_rd[11]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[11]} .single_bit_orig_name {pcpi_rd[11]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[11]/Q} .original_name {pcpi_rd[11]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[12]} .original_name {{pcpi_rd[12]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[12]} .single_bit_orig_name {pcpi_rd[12]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[12]/Q} .original_name {pcpi_rd[12]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[13]} .original_name {{pcpi_rd[13]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[13]} .single_bit_orig_name {pcpi_rd[13]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[13]/Q} .original_name {pcpi_rd[13]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[14]} .original_name {{pcpi_rd[14]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[14]} .single_bit_orig_name {pcpi_rd[14]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[14]/Q} .original_name {pcpi_rd[14]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[15]} .original_name {{pcpi_rd[15]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[15]} .single_bit_orig_name {pcpi_rd[15]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[15]/Q} .original_name {pcpi_rd[15]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[16]} .original_name {{pcpi_rd[16]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[16]} .single_bit_orig_name {pcpi_rd[16]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[16]/Q} .original_name {pcpi_rd[16]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[17]} .original_name {{pcpi_rd[17]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[17]} .single_bit_orig_name {pcpi_rd[17]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[17]/Q} .original_name {pcpi_rd[17]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[18]} .original_name {{pcpi_rd[18]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[18]} .single_bit_orig_name {pcpi_rd[18]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[18]/Q} .original_name {pcpi_rd[18]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[19]} .original_name {{pcpi_rd[19]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[19]} .single_bit_orig_name {pcpi_rd[19]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[19]/Q} .original_name {pcpi_rd[19]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[20]} .original_name {{pcpi_rd[20]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[20]} .single_bit_orig_name {pcpi_rd[20]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[20]/Q} .original_name {pcpi_rd[20]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[21]} .original_name {{pcpi_rd[21]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[21]} .single_bit_orig_name {pcpi_rd[21]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[21]/Q} .original_name {pcpi_rd[21]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[22]} .original_name {{pcpi_rd[22]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[22]} .single_bit_orig_name {pcpi_rd[22]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[22]/Q} .original_name {pcpi_rd[22]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[23]} .original_name {{pcpi_rd[23]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[23]} .single_bit_orig_name {pcpi_rd[23]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[23]/Q} .original_name {pcpi_rd[23]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[24]} .original_name {{pcpi_rd[24]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[24]} .single_bit_orig_name {pcpi_rd[24]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[24]/Q} .original_name {pcpi_rd[24]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[25]} .original_name {{pcpi_rd[25]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[25]} .single_bit_orig_name {pcpi_rd[25]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[25]/Q} .original_name {pcpi_rd[25]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[26]} .original_name {{pcpi_rd[26]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[26]} .single_bit_orig_name {pcpi_rd[26]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[26]/Q} .original_name {pcpi_rd[26]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[27]} .original_name {{pcpi_rd[27]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[27]} .single_bit_orig_name {pcpi_rd[27]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[27]/Q} .original_name {pcpi_rd[27]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[28]} .original_name {{pcpi_rd[28]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[28]} .single_bit_orig_name {pcpi_rd[28]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[28]/Q} .original_name {pcpi_rd[28]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[29]} .original_name {{pcpi_rd[29]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[29]} .single_bit_orig_name {pcpi_rd[29]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[29]/Q} .original_name {pcpi_rd[29]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[30]} .original_name {{pcpi_rd[30]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[30]} .single_bit_orig_name {pcpi_rd[30]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[30]/Q} .original_name {pcpi_rd[30]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[31]} .original_name {{pcpi_rd[31]}}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[31]} .single_bit_orig_name {pcpi_rd[31]}
set_db -quiet {inst:mac_pcpi_coprocessor/pcpi_rd_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/pcpi_rd_reg[31]/Q} .original_name {pcpi_rd[31]/q}
set_db -quiet inst:mac_pcpi_coprocessor/pcpi_wait_reg .original_name pcpi_wait
set_db -quiet inst:mac_pcpi_coprocessor/pcpi_wait_reg .orig_hdl_instantiated false
set_db -quiet inst:mac_pcpi_coprocessor/pcpi_wait_reg .single_bit_orig_name pcpi_wait
set_db -quiet inst:mac_pcpi_coprocessor/pcpi_wait_reg .gint_phase_inversion false
set_db -quiet pin:mac_pcpi_coprocessor/pcpi_wait_reg/Q .original_name pcpi_wait/q
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[0]} .original_name {{scale_a_r[0]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[0]} .single_bit_orig_name {scale_a_r[0]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_a_r_reg[0]/Q} .original_name {scale_a_r[0]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[1]} .original_name {{scale_a_r[1]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[1]} .single_bit_orig_name {scale_a_r[1]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_a_r_reg[1]/Q} .original_name {scale_a_r[1]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[2]} .original_name {{scale_a_r[2]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[2]} .single_bit_orig_name {scale_a_r[2]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_a_r_reg[2]/Q} .original_name {scale_a_r[2]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[3]} .original_name {{scale_a_r[3]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[3]} .single_bit_orig_name {scale_a_r[3]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_a_r_reg[3]/Q} .original_name {scale_a_r[3]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[4]} .original_name {{scale_a_r[4]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[4]} .single_bit_orig_name {scale_a_r[4]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_a_r_reg[4]/Q} .original_name {scale_a_r[4]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[5]} .original_name {{scale_a_r[5]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[5]} .single_bit_orig_name {scale_a_r[5]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_a_r_reg[5]/Q} .original_name {scale_a_r[5]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[6]} .original_name {{scale_a_r[6]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[6]} .single_bit_orig_name {scale_a_r[6]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_a_r_reg[6]/Q} .original_name {scale_a_r[6]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[7]} .original_name {{scale_a_r[7]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[7]} .single_bit_orig_name {scale_a_r[7]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_a_r_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_a_r_reg[7]/Q} .original_name {scale_a_r[7]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[0]} .original_name {{scale_b_r[0]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[0]} .single_bit_orig_name {scale_b_r[0]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_b_r_reg[0]/Q} .original_name {scale_b_r[0]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[1]} .original_name {{scale_b_r[1]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[1]} .single_bit_orig_name {scale_b_r[1]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_b_r_reg[1]/Q} .original_name {scale_b_r[1]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[2]} .original_name {{scale_b_r[2]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[2]} .single_bit_orig_name {scale_b_r[2]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_b_r_reg[2]/Q} .original_name {scale_b_r[2]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[3]} .original_name {{scale_b_r[3]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[3]} .single_bit_orig_name {scale_b_r[3]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_b_r_reg[3]/Q} .original_name {scale_b_r[3]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[4]} .original_name {{scale_b_r[4]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[4]} .single_bit_orig_name {scale_b_r[4]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_b_r_reg[4]/Q} .original_name {scale_b_r[4]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[5]} .original_name {{scale_b_r[5]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[5]} .single_bit_orig_name {scale_b_r[5]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_b_r_reg[5]/Q} .original_name {scale_b_r[5]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[6]} .original_name {{scale_b_r[6]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[6]} .single_bit_orig_name {scale_b_r[6]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_b_r_reg[6]/Q} .original_name {scale_b_r[6]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[7]} .original_name {{scale_b_r[7]}}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[7]} .single_bit_orig_name {scale_b_r[7]}
set_db -quiet {inst:mac_pcpi_coprocessor/scale_b_r_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/scale_b_r_reg[7]/Q} .original_name {scale_b_r[7]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/state_reg[0]} .original_name {{state[0]}}
set_db -quiet {inst:mac_pcpi_coprocessor/state_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/state_reg[0]} .single_bit_orig_name {state[0]}
set_db -quiet {inst:mac_pcpi_coprocessor/state_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/state_reg[0]/Q} .original_name {state[0]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[0]} .original_name {{tensor_scale_r[0]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[0]} .single_bit_orig_name {tensor_scale_r[0]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[0]/Q} .original_name {tensor_scale_r[0]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[1]} .original_name {{tensor_scale_r[1]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[1]} .single_bit_orig_name {tensor_scale_r[1]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[1]/Q} .original_name {tensor_scale_r[1]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[2]} .original_name {{tensor_scale_r[2]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[2]} .single_bit_orig_name {tensor_scale_r[2]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[2]/Q} .original_name {tensor_scale_r[2]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[3]} .original_name {{tensor_scale_r[3]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[3]} .single_bit_orig_name {tensor_scale_r[3]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[3]/Q} .original_name {tensor_scale_r[3]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[4]} .original_name {{tensor_scale_r[4]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[4]} .single_bit_orig_name {tensor_scale_r[4]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[4]/Q} .original_name {tensor_scale_r[4]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[5]} .original_name {{tensor_scale_r[5]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[5]} .single_bit_orig_name {tensor_scale_r[5]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[5]/Q} .original_name {tensor_scale_r[5]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[6]} .original_name {{tensor_scale_r[6]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[6]} .single_bit_orig_name {tensor_scale_r[6]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[6]/Q} .original_name {tensor_scale_r[6]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[7]} .original_name {{tensor_scale_r[7]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[7]} .single_bit_orig_name {tensor_scale_r[7]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[7]/Q} .original_name {tensor_scale_r[7]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[8]} .original_name {{tensor_scale_r[8]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[8]} .single_bit_orig_name {tensor_scale_r[8]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[8]/Q} .original_name {tensor_scale_r[8]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[9]} .original_name {{tensor_scale_r[9]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[9]} .single_bit_orig_name {tensor_scale_r[9]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[9]/Q} .original_name {tensor_scale_r[9]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[10]} .original_name {{tensor_scale_r[10]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[10]} .single_bit_orig_name {tensor_scale_r[10]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[10]/Q} .original_name {tensor_scale_r[10]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[11]} .original_name {{tensor_scale_r[11]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[11]} .single_bit_orig_name {tensor_scale_r[11]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[11]/Q} .original_name {tensor_scale_r[11]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[12]} .original_name {{tensor_scale_r[12]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[12]} .single_bit_orig_name {tensor_scale_r[12]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[12]/Q} .original_name {tensor_scale_r[12]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[13]} .original_name {{tensor_scale_r[13]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[13]} .single_bit_orig_name {tensor_scale_r[13]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[13]/Q} .original_name {tensor_scale_r[13]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[14]} .original_name {{tensor_scale_r[14]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[14]} .single_bit_orig_name {tensor_scale_r[14]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[14]/Q} .original_name {tensor_scale_r[14]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[15]} .original_name {{tensor_scale_r[15]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[15]} .single_bit_orig_name {tensor_scale_r[15]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[15]/Q} .original_name {tensor_scale_r[15]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[16]} .original_name {{tensor_scale_r[16]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[16]} .single_bit_orig_name {tensor_scale_r[16]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[16]/Q} .original_name {tensor_scale_r[16]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[17]} .original_name {{tensor_scale_r[17]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[17]} .single_bit_orig_name {tensor_scale_r[17]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[17]/Q} .original_name {tensor_scale_r[17]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[18]} .original_name {{tensor_scale_r[18]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[18]} .single_bit_orig_name {tensor_scale_r[18]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[18]/Q} .original_name {tensor_scale_r[18]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[19]} .original_name {{tensor_scale_r[19]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[19]} .single_bit_orig_name {tensor_scale_r[19]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[19]/Q} .original_name {tensor_scale_r[19]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[20]} .original_name {{tensor_scale_r[20]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[20]} .single_bit_orig_name {tensor_scale_r[20]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[20]/Q} .original_name {tensor_scale_r[20]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[21]} .original_name {{tensor_scale_r[21]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[21]} .single_bit_orig_name {tensor_scale_r[21]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[21]/Q} .original_name {tensor_scale_r[21]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[22]} .original_name {{tensor_scale_r[22]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[22]} .single_bit_orig_name {tensor_scale_r[22]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[22]/Q} .original_name {tensor_scale_r[22]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[23]} .original_name {{tensor_scale_r[23]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[23]} .single_bit_orig_name {tensor_scale_r[23]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[23]/Q} .original_name {tensor_scale_r[23]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[24]} .original_name {{tensor_scale_r[24]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[24]} .single_bit_orig_name {tensor_scale_r[24]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[24]/Q} .original_name {tensor_scale_r[24]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[25]} .original_name {{tensor_scale_r[25]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[25]} .single_bit_orig_name {tensor_scale_r[25]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[25]/Q} .original_name {tensor_scale_r[25]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[26]} .original_name {{tensor_scale_r[26]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[26]} .single_bit_orig_name {tensor_scale_r[26]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[26]/Q} .original_name {tensor_scale_r[26]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[27]} .original_name {{tensor_scale_r[27]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[27]} .single_bit_orig_name {tensor_scale_r[27]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[27]/Q} .original_name {tensor_scale_r[27]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[28]} .original_name {{tensor_scale_r[28]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[28]} .single_bit_orig_name {tensor_scale_r[28]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[28]/Q} .original_name {tensor_scale_r[28]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[29]} .original_name {{tensor_scale_r[29]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[29]} .single_bit_orig_name {tensor_scale_r[29]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[29]/Q} .original_name {tensor_scale_r[29]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[30]} .original_name {{tensor_scale_r[30]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[30]} .single_bit_orig_name {tensor_scale_r[30]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[30]/Q} .original_name {tensor_scale_r[30]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[31]} .original_name {{tensor_scale_r[31]}}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[31]} .single_bit_orig_name {tensor_scale_r[31]}
set_db -quiet {inst:mac_pcpi_coprocessor/tensor_scale_r_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/tensor_scale_r_reg[31]/Q} .original_name {tensor_scale_r[31]/q}
set_db -quiet inst:mac_pcpi_coprocessor/u_mac_g24096__5477 .seq_dup_name_count 1
set_db -quiet inst:mac_pcpi_coprocessor/u_mac_g36972__5122 .seq_dup_name_count 1
set_db -quiet inst:mac_pcpi_coprocessor/u_mac_g36443 .seq_dup_name_count 1
set_db -quiet inst:mac_pcpi_coprocessor/u_mac_g38662 .seq_dup_name_count 1
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[0]} .original_name {{u_mac/accum_out[0]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[0]} .single_bit_orig_name {u_mac/accum_out[0]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[0]/Q} .original_name {u_mac/accum_out[0]/q}
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[0]/QN} .original_name {u_mac/accum_out[0]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[2]} .original_name {{u_mac/accum_out[2]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[2]} .single_bit_orig_name {u_mac/accum_out[2]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[2]/Q} .original_name {u_mac/accum_out[2]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[4]} .original_name {{u_mac/accum_out[4]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[4]} .single_bit_orig_name {u_mac/accum_out[4]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[4]/Q} .original_name {u_mac/accum_out[4]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[5]} .original_name {{u_mac/accum_out[5]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[5]} .single_bit_orig_name {u_mac/accum_out[5]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[5]/Q} .original_name {u_mac/accum_out[5]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[6]} .original_name {{u_mac/accum_out[6]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[6]} .single_bit_orig_name {u_mac/accum_out[6]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[6]/Q} .original_name {u_mac/accum_out[6]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[7]} .original_name {{u_mac/accum_out[7]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[7]} .single_bit_orig_name {u_mac/accum_out[7]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[7]/Q} .original_name {u_mac/accum_out[7]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[8]} .original_name {{u_mac/accum_out[8]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[8]} .single_bit_orig_name {u_mac/accum_out[8]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[8]/Q} .original_name {u_mac/accum_out[8]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[9]} .original_name {{u_mac/accum_out[9]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[9]} .single_bit_orig_name {u_mac/accum_out[9]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[9]/Q} .original_name {u_mac/accum_out[9]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[10]} .original_name {{u_mac/accum_out[10]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[10]} .single_bit_orig_name {u_mac/accum_out[10]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[10]/Q} .original_name {u_mac/accum_out[10]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[11]} .original_name {{u_mac/accum_out[11]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[11]} .single_bit_orig_name {u_mac/accum_out[11]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[11]/Q} .original_name {u_mac/accum_out[11]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[12]} .original_name {{u_mac/accum_out[12]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[12]} .single_bit_orig_name {u_mac/accum_out[12]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[12]/Q} .original_name {u_mac/accum_out[12]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[13]} .original_name {{u_mac/accum_out[13]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[13]} .single_bit_orig_name {u_mac/accum_out[13]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[13]/Q} .original_name {u_mac/accum_out[13]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[14]} .original_name {{u_mac/accum_out[14]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[14]} .single_bit_orig_name {u_mac/accum_out[14]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[14]/Q} .original_name {u_mac/accum_out[14]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[15]} .original_name {{u_mac/accum_out[15]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[15]} .single_bit_orig_name {u_mac/accum_out[15]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[15]/Q} .original_name {u_mac/accum_out[15]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[16]} .original_name {{u_mac/accum_out[16]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[16]} .single_bit_orig_name {u_mac/accum_out[16]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[16]/Q} .original_name {u_mac/accum_out[16]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[17]} .original_name {{u_mac/accum_out[17]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[17]} .single_bit_orig_name {u_mac/accum_out[17]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[17]/Q} .original_name {u_mac/accum_out[17]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[18]} .original_name {{u_mac/accum_out[18]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[18]} .single_bit_orig_name {u_mac/accum_out[18]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[18]/Q} .original_name {u_mac/accum_out[18]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[19]} .original_name {{u_mac/accum_out[19]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[19]} .single_bit_orig_name {u_mac/accum_out[19]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[19]/Q} .original_name {u_mac/accum_out[19]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[20]} .original_name {{u_mac/accum_out[20]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[20]} .single_bit_orig_name {u_mac/accum_out[20]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[20]/Q} .original_name {u_mac/accum_out[20]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[21]} .original_name {{u_mac/accum_out[21]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[21]} .single_bit_orig_name {u_mac/accum_out[21]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[21]/Q} .original_name {u_mac/accum_out[21]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[22]} .original_name {{u_mac/accum_out[22]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[22]} .single_bit_orig_name {u_mac/accum_out[22]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[22]/Q} .original_name {u_mac/accum_out[22]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[24]} .original_name {{u_mac/accum_out[24]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[24]} .single_bit_orig_name {u_mac/accum_out[24]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[24]/Q} .original_name {u_mac/accum_out[24]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[25]} .original_name {{u_mac/accum_out[25]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[25]} .single_bit_orig_name {u_mac/accum_out[25]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[25]/Q} .original_name {u_mac/accum_out[25]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[26]} .original_name {{u_mac/accum_out[26]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[26]} .single_bit_orig_name {u_mac/accum_out[26]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[26]/Q} .original_name {u_mac/accum_out[26]/q}
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[26]/QN} .original_name {u_mac/accum_out[26]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[27]} .original_name {{u_mac/accum_out[27]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[27]} .single_bit_orig_name {u_mac/accum_out[27]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[27]/Q} .original_name {u_mac/accum_out[27]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[28]} .original_name {{u_mac/accum_out[28]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[28]} .single_bit_orig_name {u_mac/accum_out[28]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[28]/Q} .original_name {u_mac/accum_out[28]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[29]} .original_name {{u_mac/accum_out[29]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[29]} .single_bit_orig_name {u_mac/accum_out[29]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[29]/Q} .original_name {u_mac/accum_out[29]/q}
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[29]/QN} .original_name {u_mac/accum_out[29]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[30]} .original_name {{u_mac/accum_out[30]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[30]} .single_bit_orig_name {u_mac/accum_out[30]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[30]/Q} .original_name {u_mac/accum_out[30]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[31]} .original_name {{u_mac/accum_out[31]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[31]} .single_bit_orig_name {u_mac/accum_out[31]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[31]/Q} .original_name {u_mac/accum_out[31]/q}
set_db -quiet inst:mac_pcpi_coprocessor/u_mac_valid_out_reg .original_name u_mac/valid_out
set_db -quiet inst:mac_pcpi_coprocessor/u_mac_valid_out_reg .orig_hdl_instantiated false
set_db -quiet inst:mac_pcpi_coprocessor/u_mac_valid_out_reg .single_bit_orig_name u_mac/valid_out
set_db -quiet inst:mac_pcpi_coprocessor/u_mac_valid_out_reg .gint_phase_inversion false
set_db -quiet pin:mac_pcpi_coprocessor/u_mac_valid_out_reg/Q .original_name u_mac/valid_out/q
set_db -quiet inst:mac_pcpi_coprocessor/u_mac_g30854 .seq_dup_name_count 1
set_db -quiet inst:mac_pcpi_coprocessor/u_mac_g30956 .seq_dup_name_count 1
set_db -quiet inst:mac_pcpi_coprocessor/u_mac_g30974 .seq_dup_name_count 1
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[1]} .original_name {{u_mac/accum_out[1]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[1]} .single_bit_orig_name {u_mac/accum_out[1]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[1]/Q} .original_name {u_mac/accum_out[1]/q}
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[1]/QN} .original_name {u_mac/accum_out[1]/q}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[23]} .original_name {{u_mac/accum_out[23]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[23]} .single_bit_orig_name {u_mac/accum_out[23]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[23]/Q} .original_name {u_mac/accum_out[23]/q}
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[23]/QN} .original_name {u_mac/accum_out[23]/q}
set_db -quiet inst:mac_pcpi_coprocessor/u_mac_u_eff_mul_30_34_g4729 .seq_dup_name_count 1
set_db -quiet inst:mac_pcpi_coprocessor/fopt39778 .seq_dup_name_count 1
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[3]} .original_name {{u_mac/accum_out[3]}}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[3]} .single_bit_orig_name {u_mac/accum_out[3]}
set_db -quiet {inst:mac_pcpi_coprocessor/u_mac_accum_out_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[3]/Q} .original_name {u_mac/accum_out[3]/q}
set_db -quiet {pin:mac_pcpi_coprocessor/u_mac_accum_out_reg[3]/QN} .original_name {u_mac/accum_out[3]/q}
# BEGIN PMBIST SECTION
# END PMBIST SECTION
# BEGIN PHYSICAL ANNOTATION SECTION
# END PHYSICAL ANNOTATION SECTION
set_db -quiet source_verbose true
#############################################################
#####   FLOW WRITE   ########################################
##
## Written by Genus(TM) Synthesis Solution version 21.10-p002_1
## flowkit v21.10-d047_1
## Written on 09:30:43 30-Jun 2026
#############################################################
#####   Flow Definitions   ##################################

#############################################################
#####   Step Definitions   ##################################


#############################################################
#####   Attribute Definitions   #############################

if {[is_attribute flow_edit_end_steps -obj_type root]} {set_db flow_edit_end_steps {}}
if {[is_attribute flow_edit_start_steps -obj_type root]} {set_db flow_edit_start_steps {}}
if {[is_attribute flow_footer_tcl -obj_type root]} {set_db flow_footer_tcl {}}
if {[is_attribute flow_header_tcl -obj_type root]} {set_db flow_header_tcl {}}
if {[is_attribute flow_metadata -obj_type root]} {set_db flow_metadata {}}
if {[is_attribute flow_setup_config -obj_type root]} {set_db flow_setup_config {HUDDLE {!!map {}}}}
if {[is_attribute flow_step_begin_tcl -obj_type root]} {set_db flow_step_begin_tcl {}}
if {[is_attribute flow_step_check_tcl -obj_type root]} {set_db flow_step_check_tcl {}}
if {[is_attribute flow_step_end_tcl -obj_type root]} {set_db flow_step_end_tcl {}}
if {[is_attribute flow_step_order -obj_type root]} {set_db flow_step_order {}}
if {[is_attribute flow_summary_tcl -obj_type root]} {set_db flow_summary_tcl {}}
if {[is_attribute flow_template_feature_definition -obj_type root]} {set_db flow_template_feature_definition {}}
if {[is_attribute flow_template_type -obj_type root]} {set_db flow_template_type {}}
if {[is_attribute flow_template_tools -obj_type root]} {set_db flow_template_tools {}}
if {[is_attribute flow_template_version -obj_type root]} {set_db flow_template_version {}}
if {[is_attribute flow_user_templates -obj_type root]} {set_db flow_user_templates {}}


#############################################################
#####   Flow History   ######################################

if {[is_attribute flow_user_templates -obj_type root]} {set_db flow_user_templates {}}
if {[is_attribute flow_plugin_steps -obj_type root]} {set_db flow_plugin_steps {}}
if {[is_attribute flow_template_type -obj_type root]} {set_db flow_template_type {}}
if {[is_attribute flow_template_tools -obj_type root]} {set_db flow_template_tools {}}
if {[is_attribute flow_template_version -obj_type root]} {set_db flow_template_version {}}
if {[is_attribute flow_template_feature_definition -obj_type root]} {set_db flow_template_feature_definition {}}
if {[is_attribute flow_remark -obj_type root]} {set_db flow_remark {}}
if {[is_attribute flow_features -obj_type root]} {set_db flow_features {}}
if {[is_attribute flow_feature_values -obj_type root]} {set_db flow_feature_values {}}
if {[is_attribute flow_write_db_args -obj_type root]} {set_db flow_write_db_args {}}
if {[is_attribute flow_write_db_sdc -obj_type root]} {set_db flow_write_db_sdc true}
if {[is_attribute flow_write_db_common -obj_type root]} {set_db flow_write_db_common false}
if {[is_attribute flow_post_db_overwrite -obj_type root]} {set_db flow_post_db_overwrite {}}
if {[is_attribute flow_step_order -obj_type root]} {set_db flow_step_order {}}
if {[is_attribute flow_step_begin_tcl -obj_type root]} {set_db flow_step_begin_tcl {}}
if {[is_attribute flow_step_end_tcl -obj_type root]} {set_db flow_step_end_tcl {}}
if {[is_attribute flow_step_last -obj_type root]} {set_db flow_step_last {}}
if {[is_attribute flow_step_current -obj_type root]} {set_db flow_step_current {}}
if {[is_attribute flow_step_canonical_current -obj_type root]} {set_db flow_step_canonical_current {}}
if {[is_attribute flow_step_next -obj_type root]} {set_db flow_step_next {}}
if {[is_attribute flow_working_directory -obj_type root]} {set_db flow_working_directory .}
if {[is_attribute flow_branch -obj_type root]} {set_db flow_branch {}}
if {[is_attribute flow_caller_data -obj_type root]} {set_db flow_caller_data {}}
if {[is_attribute flow_metrics_snapshot_uuid -obj_type root]} {set_db flow_metrics_snapshot_uuid 70f29982-4988-406c-8cb5-f51cb121f188}
if {[is_attribute flow_starting_db -obj_type root]} {set_db flow_starting_db {}}
if {[is_attribute flow_db_directory -obj_type root]} {set_db flow_db_directory dbs}
if {[is_attribute flow_report_directory -obj_type root]} {set_db flow_report_directory reports}
if {[is_attribute flow_log_directory -obj_type root]} {set_db flow_log_directory logs}
if {[is_attribute flow_mail_to -obj_type root]} {set_db flow_mail_to {}}
if {[is_attribute flow_exit_when_done -obj_type root]} {set_db flow_exit_when_done false}
if {[is_attribute flow_mail_on_error -obj_type root]} {set_db flow_mail_on_error false}
if {[is_attribute flow_summary_tcl -obj_type root]} {set_db flow_summary_tcl {}}
if {[is_attribute flow_history -obj_type root]} {set_db flow_history {}}
if {[is_attribute flow_step_last_status -obj_type root]} {set_db flow_step_last_status not_run}
if {[is_attribute flow_step_last_msg -obj_type root]} {set_db flow_step_last_msg {}}
if {[is_attribute flow_run_tag -obj_type root]} {set_db flow_run_tag {}}
if {[is_attribute flow_current_cache -obj_type root]} {set_db flow_current_cache {}}
if {[is_attribute flow_step_order_cache -obj_type root]} {set_db flow_step_order_cache {}}
if {[is_attribute flow_step_results_cache -obj_type root]} {set_db flow_step_results_cache {}}
if {[is_attribute flow_metadata -obj_type root]} {set_db flow_metadata {}}
if {[is_attribute flow_execute_in_global -obj_type root]} {set_db flow_execute_in_global true}
if {[is_attribute flow_overwrite_db -obj_type root]} {set_db flow_overwrite_db false}
if {[is_attribute flow_print_run_information -obj_type root]} {set_db flow_print_run_information false}
if {[is_attribute flow_verbose -obj_type root]} {set_db flow_verbose true}
if {[is_attribute flow_print_run_information_full -obj_type root]} {set_db flow_print_run_information_full false}
if {[is_attribute flow_header_tcl -obj_type root]} {set_db flow_header_tcl {}}
if {[is_attribute flow_footer_tcl -obj_type root]} {set_db flow_footer_tcl {}}
if {[is_attribute flow_init_header_tcl -obj_type root]} {set_db flow_init_header_tcl {}}
if {[is_attribute flow_init_footer_tcl -obj_type root]} {set_db flow_init_footer_tcl {}}
if {[is_attribute flow_edit_start_steps -obj_type root]} {set_db flow_edit_start_steps {}}
if {[is_attribute flow_edit_end_steps -obj_type root]} {set_db flow_edit_end_steps {}}
if {[is_attribute flow_step_last_number -obj_type root]} {set_db flow_step_last_number 0}
if {[is_attribute flow_autoload_applets -obj_type root]} {set_db flow_autoload_applets false}
if {[is_attribute flow_autoload_dir -obj_type root]} {set_db flow_autoload_dir error}
if {[is_attribute flow_skip_auto_db_save -obj_type root]} {set_db flow_skip_auto_db_save true}
if {[is_attribute flow_skip_auto_generate_metrics -obj_type root]} {set_db flow_skip_auto_generate_metrics false}
if {[is_attribute flow_top -obj_type root]} {set_db flow_top {}}
if {[is_attribute flow_hier_path -obj_type root]} {set_db flow_hier_path {}}
if {[is_attribute flow_schedule -obj_type root]} {set_db flow_schedule {}}
if {[is_attribute flow_step_check_tcl -obj_type root]} {set_db flow_step_check_tcl {}}
if {[is_attribute flow_script -obj_type root]} {set_db flow_script {}}
if {[is_attribute flow_yaml_script -obj_type root]} {set_db flow_yaml_script {}}
if {[is_attribute flow_cla_enabled_features -obj_type root]} {set_db flow_cla_enabled_features {}}
if {[is_attribute flow_cla_inject_tcl -obj_type root]} {set_db flow_cla_inject_tcl {}}
if {[is_attribute flow_error_message -obj_type root]} {set_db flow_error_message {}}
if {[is_attribute flow_error_errorinfo -obj_type root]} {set_db flow_error_errorinfo {}}
if {[is_attribute flow_reset_time_after_flow_init -obj_type root]} {set_db flow_reset_time_after_flow_init false}
if {[is_attribute flow_error_write_db -obj_type root]} {set_db flow_error_write_db true}
if {[is_attribute flow_advanced_metric_isolation -obj_type root]} {set_db flow_advanced_metric_isolation flow}
if {[is_attribute flow_yaml_root -obj_type root]} {set_db flow_yaml_root {}}
if {[is_attribute flow_yaml_root_dir -obj_type root]} {set_db flow_yaml_root_dir {}}
if {[is_attribute flow_setup_config -obj_type root]} {set_db flow_setup_config {HUDDLE {!!map {}}}}
if {[is_attribute flow_yamllint_exec -obj_type root]} {set_db flow_yamllint_exec yamllint}

#############################################################
#####   User Defined Attributes   ###########################

