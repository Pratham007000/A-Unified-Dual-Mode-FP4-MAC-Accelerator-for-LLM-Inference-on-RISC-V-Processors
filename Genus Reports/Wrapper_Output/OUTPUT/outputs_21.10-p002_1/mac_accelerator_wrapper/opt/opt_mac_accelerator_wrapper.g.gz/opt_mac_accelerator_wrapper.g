######################################################################

# Created by Genus(TM) Synthesis Solution 21.10-p002_1 on Sun Jun 21 21:23:57 IST 2026

# This file contains the Genus script for design:mac_accelerator_wrapper

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path {/home/redhatacademy19/Documents/Satyam_SRIP/gsclib045_all_v4.8/gsclib045/timing /home/redhatacademy19/Documents/Satyam_SRIP/gsclib045_all_v4.8/gsclib045_hvt/timing /home/redhatacademy19/Documents/Satyam_SRIP/gsclib045_all_v4.8/gsclib045_lvt/timing}
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{PBS_Generic-Start 0 34 0.0 7.0} {to_generic 240 275 240 248} {first_condense 18 296 23 274} {PBS_Generic_Opt-Post 277 311 276.288763 283.288763} {{PBS_Generic-Postgen HBO Optimizations} 0 311 0.0 283.288763} {PBS_TechMap-Start 0 313 0.0 285.287537} {{PBS_TechMap-Premap HBO Optimizations} 0 313 0.0 285.287537} {second_condense 10 323 15 306} {reify 24 347 52 359} {global_incr_map 9 356 9 369} {{PBS_Techmap-Global Mapping} 65 378 64.47539000000006 349.76292700000005} {{PBS_TechMap-Datapath Postmap Operations} 0 378 0.9797590000000014 350.74268600000005} {{PBS_TechMap-Postmap HBO Optimizations} 0 378 -0.021161000000006425 350.72152500000004} {{PBS_TechMap-Postmap Clock Gating} 1 379 1.0 351.72152500000004} {{PBS_TechMap-Postmap Cleanup} 11 390 11.964328999999964 363.685854} {PBS_Techmap-Post_MBCI 0 390 0.0 363.685854} {incr_opt 565 958 570 975} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tinfo_tstamp_file .rs_redhatacademy19.tstamp
set_db -quiet metric_enable true
set_db -quiet script_search_path /home/redhatacademy19/Documents/Satyam_SRIP/scripts
set_db -quiet use_area_from_lef true
set_db -quiet flow_metrics_snapshot_uuid 4ec69ea4-8997-449e-942d-3feae6fc1e24
set_db -quiet phys_use_segment_parasitics true
set_db -quiet probabilistic_extraction true
set_db -quiet ple_correlation_factors {1.9000 2.0000}
set_db -quiet maximum_interval_of_vias inf
set_db -quiet layer_aware_buffer true
set_db -quiet ple_mode global
set_db -quiet wireload_selection none
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/PVT_1P32V_0C .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/_nominal_ .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/PVT_1P32V_0C .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/_nominal_ .tree_type balanced_tree
# BEGIN MSV SECTION
# END MSV SECTION
define_clock -name clk -domain domain_1 -period 2000.0 -divide_period 1 -rise 0 -divide_rise 1 -fall 1 -divide_fall 2 -remove -design design:mac_accelerator_wrapper port:mac_accelerator_wrapper/clk
define_cost_group -design design:mac_accelerator_wrapper -name clk
external_delay -accumulate -input {0.0 no_value 0.0 no_value} -clock clock:mac_accelerator_wrapper/clk -name create_clock_delay_domain_1_clk_R_0 port:mac_accelerator_wrapper/clk
set_db -quiet external_delay:mac_accelerator_wrapper/create_clock_delay_domain_1_clk_R_0 .clock_network_latency_included true
external_delay -accumulate -input {no_value 0.0 no_value 0.0} -clock clock:mac_accelerator_wrapper/clk -edge_fall -name create_clock_delay_domain_1_clk_F_0 port:mac_accelerator_wrapper/clk
set_db -quiet external_delay:mac_accelerator_wrapper/create_clock_delay_domain_1_clk_F_0 .clock_network_latency_included true
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8 port:mac_accelerator_wrapper/rst
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_1_1 port:mac_accelerator_wrapper/cs
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_2_1 port:mac_accelerator_wrapper/we
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_3_1 {{port:mac_accelerator_wrapper/addr[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_4_1 {{port:mac_accelerator_wrapper/addr[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_5_1 {{port:mac_accelerator_wrapper/addr[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_6_1 {{port:mac_accelerator_wrapper/addr[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_7_1 {{port:mac_accelerator_wrapper/addr[0]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_8_1 {{port:mac_accelerator_wrapper/wdata[31]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_9_1 {{port:mac_accelerator_wrapper/wdata[30]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_10_1 {{port:mac_accelerator_wrapper/wdata[29]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_11_1 {{port:mac_accelerator_wrapper/wdata[28]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_12_1 {{port:mac_accelerator_wrapper/wdata[27]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_13_1 {{port:mac_accelerator_wrapper/wdata[26]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_14_1 {{port:mac_accelerator_wrapper/wdata[25]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_15_1 {{port:mac_accelerator_wrapper/wdata[24]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_16_1 {{port:mac_accelerator_wrapper/wdata[23]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_17_1 {{port:mac_accelerator_wrapper/wdata[22]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_18_1 {{port:mac_accelerator_wrapper/wdata[21]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_19_1 {{port:mac_accelerator_wrapper/wdata[20]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_20_1 {{port:mac_accelerator_wrapper/wdata[19]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_21_1 {{port:mac_accelerator_wrapper/wdata[18]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_22_1 {{port:mac_accelerator_wrapper/wdata[17]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_23_1 {{port:mac_accelerator_wrapper/wdata[16]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_24_1 {{port:mac_accelerator_wrapper/wdata[15]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_25_1 {{port:mac_accelerator_wrapper/wdata[14]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_26_1 {{port:mac_accelerator_wrapper/wdata[13]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_27_1 {{port:mac_accelerator_wrapper/wdata[12]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_28_1 {{port:mac_accelerator_wrapper/wdata[11]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_29_1 {{port:mac_accelerator_wrapper/wdata[10]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_30_1 {{port:mac_accelerator_wrapper/wdata[9]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_31_1 {{port:mac_accelerator_wrapper/wdata[8]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_32_1 {{port:mac_accelerator_wrapper/wdata[7]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_33_1 {{port:mac_accelerator_wrapper/wdata[6]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_34_1 {{port:mac_accelerator_wrapper/wdata[5]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_35_1 {{port:mac_accelerator_wrapper/wdata[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_36_1 {{port:mac_accelerator_wrapper/wdata[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_37_1 {{port:mac_accelerator_wrapper/wdata[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_38_1 {{port:mac_accelerator_wrapper/wdata[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_8_39_1 {{port:mac_accelerator_wrapper/wdata[0]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9 {{port:mac_accelerator_wrapper/rdata[31]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_39_1 {{port:mac_accelerator_wrapper/rdata[30]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_40_1 {{port:mac_accelerator_wrapper/rdata[29]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_41_1 {{port:mac_accelerator_wrapper/rdata[28]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_42_1 {{port:mac_accelerator_wrapper/rdata[27]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_43_1 {{port:mac_accelerator_wrapper/rdata[26]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_44_1 {{port:mac_accelerator_wrapper/rdata[25]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_45_1 {{port:mac_accelerator_wrapper/rdata[24]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_46_1 {{port:mac_accelerator_wrapper/rdata[23]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_47_1 {{port:mac_accelerator_wrapper/rdata[22]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_48_1 {{port:mac_accelerator_wrapper/rdata[21]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_49_1 {{port:mac_accelerator_wrapper/rdata[20]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_50_1 {{port:mac_accelerator_wrapper/rdata[19]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_51_1 {{port:mac_accelerator_wrapper/rdata[18]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_52_1 {{port:mac_accelerator_wrapper/rdata[17]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_53_1 {{port:mac_accelerator_wrapper/rdata[16]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_54_1 {{port:mac_accelerator_wrapper/rdata[15]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_55_1 {{port:mac_accelerator_wrapper/rdata[14]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_56_1 {{port:mac_accelerator_wrapper/rdata[13]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_57_1 {{port:mac_accelerator_wrapper/rdata[12]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_58_1 {{port:mac_accelerator_wrapper/rdata[11]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_59_1 {{port:mac_accelerator_wrapper/rdata[10]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_60_1 {{port:mac_accelerator_wrapper/rdata[9]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_61_1 {{port:mac_accelerator_wrapper/rdata[8]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_62_1 {{port:mac_accelerator_wrapper/rdata[7]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_63_1 {{port:mac_accelerator_wrapper/rdata[6]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_64_1 {{port:mac_accelerator_wrapper/rdata[5]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_65_1 {{port:mac_accelerator_wrapper/rdata[4]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_66_1 {{port:mac_accelerator_wrapper/rdata[3]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_67_1 {{port:mac_accelerator_wrapper/rdata[2]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_68_1 {{port:mac_accelerator_wrapper/rdata[1]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mac_accelerator_wrapper/clk -name mac_unit.sdc_line_9_69_1 {{port:mac_accelerator_wrapper/rdata[0]}}
path_group -paths [specify_paths -to clock:mac_accelerator_wrapper/clk]  -name clk -group cost_group:mac_accelerator_wrapper/clk -user_priority -1047552
path_disable -paths [specify_paths -lenient -from port:mac_accelerator_wrapper/rst]  -name mac_unit.sdc_line_12 -user_priority -770048
set_db -quiet exception:mac_accelerator_wrapper/mac_unit.sdc_line_12 .sdc_filename_linenumber {{/home/redhatacademy19/Documents/Satyam_SRIP/genus/mac_unit.sdc 12}}
# BEGIN DFT SECTION
set_db -quiet dft_scan_style muxed_scan
set_db -quiet dft_scanbit_waveform_analysis false
# END DFT SECTION
set_db -quiet design:mac_accelerator_wrapper .seq_reason_deleted_internal {{u_mac/mode_out_reg unloaded u_mac/mode_out} {{state_reg[2]} {{constant 0}} {state[2]}}}
set_db -quiet design:mac_accelerator_wrapper .qos_by_stage {{to_generic {wns -11111111} {tns -111111111} {vep -111111111} {area 38574} {cell_count 13306} {utilization  0.00} {runtime 240 275 240 248} }{first_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 47294} {cell_count 17313} {utilization  0.00} {runtime 18 296 23 274} }{second_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 46983} {cell_count 17201} {utilization  0.00} {runtime 10 323 15 306} }{reify {wns -269} {tns 8267} {vep 32} {area 40332} {cell_count 11104} {utilization  0.00} {runtime 24 347 52 359} }{global_incr_map {wns -271} {tns 8356} {vep 32} {area 27129} {cell_count 8944} {utilization  0.00} {runtime 9 356 9 369} }{incr_opt {wns -70} {tns 2170} {vep 32} {area 32420} {cell_count 9997} {utilization  0.00} {runtime 565 958 570 975} }}
set_db -quiet design:mac_accelerator_wrapper .is_sop_cluster true
set_db -quiet design:mac_accelerator_wrapper .seq_mbci_coverage 0.0
set_db -quiet design:mac_accelerator_wrapper .hdl_user_name mac_accelerator_wrapper
set_db -quiet design:mac_accelerator_wrapper .hdl_filelist {{default -v2001 {SYNTHESIS} {/home/redhatacademy19/Documents/Satyam_SRIP/rtl/common/nibble_extractor.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/common/e2m1_decoder.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/common/fp32_mul.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/common/fp32_add.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/mxfp4/e8m0_decoder.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/nvfp4/fp8_e4m3_decoder.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/unified/unified_mac_top.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/wrapper/mac_accelerator_wrapper.v} {/home/redhatacademy19/Documents/Satyam_SRIP/rtl} {}}}
set_db -quiet design:mac_accelerator_wrapper .verification_directory fv/mac_accelerator_wrapper
set_db -quiet design:mac_accelerator_wrapper .seq_reason_deleted {{u_mac/mode_out_reg unloaded} {{state_reg[2]} {{constant 0}}}}
set_db -quiet design:mac_accelerator_wrapper .lp_clock_gating_max_flops inf
set_db -quiet design:mac_accelerator_wrapper .arch_filename /home/redhatacademy19/Documents/Satyam_SRIP/rtl/wrapper/mac_accelerator_wrapper.v
set_db -quiet design:mac_accelerator_wrapper .entity_filename /home/redhatacademy19/Documents/Satyam_SRIP/rtl/wrapper/mac_accelerator_wrapper.v
set_db -quiet port:mac_accelerator_wrapper/clk .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/clk .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/clk .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/clk .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/clk .original_name clk
set_db -quiet port:mac_accelerator_wrapper/rst .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/rst .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/rst .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/rst .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/rst .original_name rst
set_db -quiet port:mac_accelerator_wrapper/cs .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/cs .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/cs .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/cs .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/cs .original_name cs
set_db -quiet port:mac_accelerator_wrapper/we .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/we .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/we .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/we .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mac_accelerator_wrapper/we .original_name we
set_db -quiet {port:mac_accelerator_wrapper/addr[4]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[4]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[4]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[4]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[4]} .original_name {addr[4]}
set_db -quiet {port:mac_accelerator_wrapper/addr[3]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[3]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[3]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[3]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[3]} .original_name {addr[3]}
set_db -quiet {port:mac_accelerator_wrapper/addr[2]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[2]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[2]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[2]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[2]} .original_name {addr[2]}
set_db -quiet {port:mac_accelerator_wrapper/addr[1]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[1]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[1]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[1]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[1]} .original_name {addr[1]}
set_db -quiet {port:mac_accelerator_wrapper/addr[0]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[0]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[0]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[0]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/addr[0]} .original_name {addr[0]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[31]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[31]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[31]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[31]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[31]} .original_name {wdata[31]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[30]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[30]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[30]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[30]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[30]} .original_name {wdata[30]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[29]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[29]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[29]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[29]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[29]} .original_name {wdata[29]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[28]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[28]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[28]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[28]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[28]} .original_name {wdata[28]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[27]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[27]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[27]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[27]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[27]} .original_name {wdata[27]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[26]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[26]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[26]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[26]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[26]} .original_name {wdata[26]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[25]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[25]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[25]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[25]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[25]} .original_name {wdata[25]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[24]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[24]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[24]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[24]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[24]} .original_name {wdata[24]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[23]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[23]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[23]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[23]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[23]} .original_name {wdata[23]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[22]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[22]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[22]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[22]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[22]} .original_name {wdata[22]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[21]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[21]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[21]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[21]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[21]} .original_name {wdata[21]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[20]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[20]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[20]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[20]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[20]} .original_name {wdata[20]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[19]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[19]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[19]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[19]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[19]} .original_name {wdata[19]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[18]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[18]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[18]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[18]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[18]} .original_name {wdata[18]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[17]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[17]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[17]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[17]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[17]} .original_name {wdata[17]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[16]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[16]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[16]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[16]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[16]} .original_name {wdata[16]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[15]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[15]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[15]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[15]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[15]} .original_name {wdata[15]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[14]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[14]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[14]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[14]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[14]} .original_name {wdata[14]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[13]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[13]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[13]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[13]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[13]} .original_name {wdata[13]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[12]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[12]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[12]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[12]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[12]} .original_name {wdata[12]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[11]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[11]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[11]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[11]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[11]} .original_name {wdata[11]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[10]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[10]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[10]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[10]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[10]} .original_name {wdata[10]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[9]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[9]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[9]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[9]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[9]} .original_name {wdata[9]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[8]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[8]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[8]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[8]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[8]} .original_name {wdata[8]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[7]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[7]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[7]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[7]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[7]} .original_name {wdata[7]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[6]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[6]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[6]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[6]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[6]} .original_name {wdata[6]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[5]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[5]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[5]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[5]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[5]} .original_name {wdata[5]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[4]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[4]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[4]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[4]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[4]} .original_name {wdata[4]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[3]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[3]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[3]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[3]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[3]} .original_name {wdata[3]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[2]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[2]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[2]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[2]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[2]} .original_name {wdata[2]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[1]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[1]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[1]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[1]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[1]} .original_name {wdata[1]}
set_db -quiet {port:mac_accelerator_wrapper/wdata[0]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[0]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[0]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[0]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mac_accelerator_wrapper/wdata[0]} .original_name {wdata[0]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[31]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[31]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[31]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[31]} .original_name {rdata[31]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[31]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[30]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[30]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[30]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[30]} .original_name {rdata[30]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[30]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[29]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[29]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[29]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[29]} .original_name {rdata[29]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[29]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[28]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[28]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[28]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[28]} .original_name {rdata[28]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[28]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[27]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[27]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[27]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[27]} .original_name {rdata[27]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[27]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[26]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[26]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[26]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[26]} .original_name {rdata[26]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[26]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[25]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[25]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[25]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[25]} .original_name {rdata[25]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[25]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[24]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[24]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[24]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[24]} .original_name {rdata[24]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[24]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[23]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[23]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[23]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[23]} .original_name {rdata[23]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[23]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[22]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[22]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[22]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[22]} .original_name {rdata[22]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[22]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[21]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[21]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[21]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[21]} .original_name {rdata[21]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[21]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[20]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[20]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[20]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[20]} .original_name {rdata[20]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[20]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[19]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[19]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[19]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[19]} .original_name {rdata[19]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[19]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[18]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[18]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[18]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[18]} .original_name {rdata[18]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[18]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[17]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[17]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[17]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[17]} .original_name {rdata[17]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[17]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[16]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[16]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[16]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[16]} .original_name {rdata[16]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[16]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[15]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[15]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[15]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[15]} .original_name {rdata[15]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[15]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[14]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[14]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[14]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[14]} .original_name {rdata[14]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[14]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[13]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[13]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[13]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[13]} .original_name {rdata[13]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[13]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[12]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[12]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[12]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[12]} .original_name {rdata[12]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[12]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[11]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[11]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[11]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[11]} .original_name {rdata[11]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[11]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[10]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[10]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[10]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[10]} .original_name {rdata[10]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[10]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[9]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[9]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[9]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[9]} .original_name {rdata[9]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[9]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[8]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[8]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[8]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[8]} .original_name {rdata[8]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[8]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[7]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[7]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[7]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[7]} .original_name {rdata[7]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[7]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[6]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[6]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[6]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[6]} .original_name {rdata[6]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[6]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[5]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[5]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[5]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[5]} .original_name {rdata[5]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[5]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[4]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[4]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[4]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[4]} .original_name {rdata[4]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[4]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[3]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[3]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[3]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[3]} .original_name {rdata[3]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[3]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[2]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[2]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[2]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[2]} .original_name {rdata[2]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[2]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[1]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[1]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[1]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[1]} .original_name {rdata[1]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[1]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[0]} .external_pin_cap_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[0]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mac_accelerator_wrapper/rdata[0]} .external_capacitance_min 10.0
set_db -quiet {port:mac_accelerator_wrapper/rdata[0]} .original_name {rdata[0]}
set_db -quiet {port:mac_accelerator_wrapper/rdata[0]} .external_pin_cap {10.0 10.0}
set_db -quiet inst:mac_accelerator_wrapper/done_flag_reg .original_name done_flag
set_db -quiet inst:mac_accelerator_wrapper/done_flag_reg .orig_hdl_instantiated false
set_db -quiet inst:mac_accelerator_wrapper/done_flag_reg .single_bit_orig_name done_flag
set_db -quiet inst:mac_accelerator_wrapper/done_flag_reg .gint_phase_inversion false
set_db -quiet pin:mac_accelerator_wrapper/done_flag_reg/Q .original_name done_flag/q
set_db -quiet inst:mac_accelerator_wrapper/mac_valid_in_reg .original_name mac_valid_in
set_db -quiet inst:mac_accelerator_wrapper/mac_valid_in_reg .orig_hdl_instantiated false
set_db -quiet inst:mac_accelerator_wrapper/mac_valid_in_reg .single_bit_orig_name mac_valid_in
set_db -quiet inst:mac_accelerator_wrapper/mac_valid_in_reg .gint_phase_inversion false
set_db -quiet pin:mac_accelerator_wrapper/mac_valid_in_reg/Q .original_name mac_valid_in/q
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[0]} .original_name {{reg_b0[0]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[0]} .single_bit_orig_name {reg_b0[0]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[0]/Q} .original_name {reg_b0[0]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[1]} .original_name {{reg_b0[1]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[1]} .single_bit_orig_name {reg_b0[1]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[1]/Q} .original_name {reg_b0[1]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[2]} .original_name {{reg_b0[2]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[2]} .single_bit_orig_name {reg_b0[2]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[2]/Q} .original_name {reg_b0[2]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[3]} .original_name {{reg_b0[3]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[3]} .single_bit_orig_name {reg_b0[3]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[3]/Q} .original_name {reg_b0[3]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[4]} .original_name {{reg_b0[4]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[4]} .single_bit_orig_name {reg_b0[4]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[4]/Q} .original_name {reg_b0[4]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[5]} .original_name {{reg_b0[5]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[5]} .single_bit_orig_name {reg_b0[5]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[5]/Q} .original_name {reg_b0[5]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[6]} .original_name {{reg_b0[6]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[6]} .single_bit_orig_name {reg_b0[6]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[6]/Q} .original_name {reg_b0[6]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[7]} .original_name {{reg_b0[7]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[7]} .single_bit_orig_name {reg_b0[7]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[7]/Q} .original_name {reg_b0[7]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[8]} .original_name {{reg_b0[8]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[8]} .single_bit_orig_name {reg_b0[8]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[8]/Q} .original_name {reg_b0[8]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[9]} .original_name {{reg_b0[9]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[9]} .single_bit_orig_name {reg_b0[9]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[9]/Q} .original_name {reg_b0[9]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[10]} .original_name {{reg_b0[10]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[10]} .single_bit_orig_name {reg_b0[10]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[10]/Q} .original_name {reg_b0[10]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[11]} .original_name {{reg_b0[11]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[11]} .single_bit_orig_name {reg_b0[11]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[11]/Q} .original_name {reg_b0[11]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[12]} .original_name {{reg_b0[12]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[12]} .single_bit_orig_name {reg_b0[12]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[12]/Q} .original_name {reg_b0[12]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[13]} .original_name {{reg_b0[13]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[13]} .single_bit_orig_name {reg_b0[13]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[13]/Q} .original_name {reg_b0[13]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[14]} .original_name {{reg_b0[14]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[14]} .single_bit_orig_name {reg_b0[14]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[14]/Q} .original_name {reg_b0[14]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[15]} .original_name {{reg_b0[15]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[15]} .single_bit_orig_name {reg_b0[15]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[15]/Q} .original_name {reg_b0[15]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[16]} .original_name {{reg_b0[16]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[16]} .single_bit_orig_name {reg_b0[16]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[16]/Q} .original_name {reg_b0[16]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[17]} .original_name {{reg_b0[17]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[17]} .single_bit_orig_name {reg_b0[17]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[17]/Q} .original_name {reg_b0[17]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[18]} .original_name {{reg_b0[18]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[18]} .single_bit_orig_name {reg_b0[18]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[18]/Q} .original_name {reg_b0[18]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[19]} .original_name {{reg_b0[19]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[19]} .single_bit_orig_name {reg_b0[19]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[19]/Q} .original_name {reg_b0[19]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[20]} .original_name {{reg_b0[20]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[20]} .single_bit_orig_name {reg_b0[20]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[20]/Q} .original_name {reg_b0[20]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[21]} .original_name {{reg_b0[21]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[21]} .single_bit_orig_name {reg_b0[21]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[21]/Q} .original_name {reg_b0[21]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[22]} .original_name {{reg_b0[22]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[22]} .single_bit_orig_name {reg_b0[22]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[22]/Q} .original_name {reg_b0[22]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[23]} .original_name {{reg_b0[23]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[23]} .single_bit_orig_name {reg_b0[23]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[23]/Q} .original_name {reg_b0[23]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[24]} .original_name {{reg_b0[24]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[24]} .single_bit_orig_name {reg_b0[24]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[24]/Q} .original_name {reg_b0[24]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[25]} .original_name {{reg_b0[25]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[25]} .single_bit_orig_name {reg_b0[25]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[25]/Q} .original_name {reg_b0[25]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[26]} .original_name {{reg_b0[26]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[26]} .single_bit_orig_name {reg_b0[26]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[26]/Q} .original_name {reg_b0[26]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[27]} .original_name {{reg_b0[27]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[27]} .single_bit_orig_name {reg_b0[27]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[27]/Q} .original_name {reg_b0[27]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[28]} .original_name {{reg_b0[28]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[28]} .single_bit_orig_name {reg_b0[28]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[28]/Q} .original_name {reg_b0[28]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[29]} .original_name {{reg_b0[29]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[29]} .single_bit_orig_name {reg_b0[29]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[29]/Q} .original_name {reg_b0[29]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[30]} .original_name {{reg_b0[30]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[30]} .single_bit_orig_name {reg_b0[30]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[30]/Q} .original_name {reg_b0[30]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[31]} .original_name {{reg_b0[31]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[31]} .single_bit_orig_name {reg_b0[31]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b0_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b0_reg[31]/Q} .original_name {reg_b0[31]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[0]} .original_name {{reg_b1[0]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[0]} .single_bit_orig_name {reg_b1[0]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[0]/Q} .original_name {reg_b1[0]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[1]} .original_name {{reg_b1[1]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[1]} .single_bit_orig_name {reg_b1[1]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[1]/Q} .original_name {reg_b1[1]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[2]} .original_name {{reg_b1[2]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[2]} .single_bit_orig_name {reg_b1[2]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[2]/Q} .original_name {reg_b1[2]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[3]} .original_name {{reg_b1[3]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[3]} .single_bit_orig_name {reg_b1[3]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[3]/Q} .original_name {reg_b1[3]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[4]} .original_name {{reg_b1[4]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[4]} .single_bit_orig_name {reg_b1[4]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[4]/Q} .original_name {reg_b1[4]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[5]} .original_name {{reg_b1[5]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[5]} .single_bit_orig_name {reg_b1[5]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[5]/Q} .original_name {reg_b1[5]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[6]} .original_name {{reg_b1[6]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[6]} .single_bit_orig_name {reg_b1[6]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[6]/Q} .original_name {reg_b1[6]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[7]} .original_name {{reg_b1[7]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[7]} .single_bit_orig_name {reg_b1[7]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[7]/Q} .original_name {reg_b1[7]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[8]} .original_name {{reg_b1[8]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[8]} .single_bit_orig_name {reg_b1[8]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[8]/Q} .original_name {reg_b1[8]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[9]} .original_name {{reg_b1[9]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[9]} .single_bit_orig_name {reg_b1[9]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[9]/Q} .original_name {reg_b1[9]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[10]} .original_name {{reg_b1[10]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[10]} .single_bit_orig_name {reg_b1[10]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[10]/Q} .original_name {reg_b1[10]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[11]} .original_name {{reg_b1[11]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[11]} .single_bit_orig_name {reg_b1[11]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[11]/Q} .original_name {reg_b1[11]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[12]} .original_name {{reg_b1[12]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[12]} .single_bit_orig_name {reg_b1[12]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[12]/Q} .original_name {reg_b1[12]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[13]} .original_name {{reg_b1[13]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[13]} .single_bit_orig_name {reg_b1[13]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[13]/Q} .original_name {reg_b1[13]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[14]} .original_name {{reg_b1[14]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[14]} .single_bit_orig_name {reg_b1[14]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[14]/Q} .original_name {reg_b1[14]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[15]} .original_name {{reg_b1[15]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[15]} .single_bit_orig_name {reg_b1[15]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[15]/Q} .original_name {reg_b1[15]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[16]} .original_name {{reg_b1[16]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[16]} .single_bit_orig_name {reg_b1[16]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[16]/Q} .original_name {reg_b1[16]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[17]} .original_name {{reg_b1[17]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[17]} .single_bit_orig_name {reg_b1[17]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[17]/Q} .original_name {reg_b1[17]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[18]} .original_name {{reg_b1[18]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[18]} .single_bit_orig_name {reg_b1[18]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[18]/Q} .original_name {reg_b1[18]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[19]} .original_name {{reg_b1[19]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[19]} .single_bit_orig_name {reg_b1[19]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[19]/Q} .original_name {reg_b1[19]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[20]} .original_name {{reg_b1[20]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[20]} .single_bit_orig_name {reg_b1[20]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[20]/Q} .original_name {reg_b1[20]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[21]} .original_name {{reg_b1[21]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[21]} .single_bit_orig_name {reg_b1[21]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[21]/Q} .original_name {reg_b1[21]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[22]} .original_name {{reg_b1[22]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[22]} .single_bit_orig_name {reg_b1[22]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[22]/Q} .original_name {reg_b1[22]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[23]} .original_name {{reg_b1[23]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[23]} .single_bit_orig_name {reg_b1[23]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[23]/Q} .original_name {reg_b1[23]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[24]} .original_name {{reg_b1[24]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[24]} .single_bit_orig_name {reg_b1[24]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[24]/Q} .original_name {reg_b1[24]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[25]} .original_name {{reg_b1[25]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[25]} .single_bit_orig_name {reg_b1[25]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[25]/Q} .original_name {reg_b1[25]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[26]} .original_name {{reg_b1[26]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[26]} .single_bit_orig_name {reg_b1[26]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[26]/Q} .original_name {reg_b1[26]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[27]} .original_name {{reg_b1[27]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[27]} .single_bit_orig_name {reg_b1[27]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[27]/Q} .original_name {reg_b1[27]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[28]} .original_name {{reg_b1[28]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[28]} .single_bit_orig_name {reg_b1[28]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[28]/Q} .original_name {reg_b1[28]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[29]} .original_name {{reg_b1[29]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[29]} .single_bit_orig_name {reg_b1[29]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[29]/Q} .original_name {reg_b1[29]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[30]} .original_name {{reg_b1[30]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[30]} .single_bit_orig_name {reg_b1[30]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[30]/Q} .original_name {reg_b1[30]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[31]} .original_name {{reg_b1[31]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[31]} .single_bit_orig_name {reg_b1[31]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_b1_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_b1_reg[31]/Q} .original_name {reg_b1[31]/q}
set_db -quiet inst:mac_accelerator_wrapper/reg_format_mode_reg .original_name reg_format_mode
set_db -quiet inst:mac_accelerator_wrapper/reg_format_mode_reg .orig_hdl_instantiated false
set_db -quiet inst:mac_accelerator_wrapper/reg_format_mode_reg .single_bit_orig_name reg_format_mode
set_db -quiet inst:mac_accelerator_wrapper/reg_format_mode_reg .gint_phase_inversion false
set_db -quiet pin:mac_accelerator_wrapper/reg_format_mode_reg/Q .original_name reg_format_mode/q
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[0]} .original_name {{reg_packed_byte[0]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[0]} .single_bit_orig_name {reg_packed_byte[0]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_packed_byte_reg[0]/Q} .original_name {reg_packed_byte[0]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[1]} .original_name {{reg_packed_byte[1]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[1]} .single_bit_orig_name {reg_packed_byte[1]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_packed_byte_reg[1]/Q} .original_name {reg_packed_byte[1]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[2]} .original_name {{reg_packed_byte[2]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[2]} .single_bit_orig_name {reg_packed_byte[2]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_packed_byte_reg[2]/Q} .original_name {reg_packed_byte[2]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[3]} .original_name {{reg_packed_byte[3]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[3]} .single_bit_orig_name {reg_packed_byte[3]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_packed_byte_reg[3]/Q} .original_name {reg_packed_byte[3]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[4]} .original_name {{reg_packed_byte[4]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[4]} .single_bit_orig_name {reg_packed_byte[4]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_packed_byte_reg[4]/Q} .original_name {reg_packed_byte[4]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[5]} .original_name {{reg_packed_byte[5]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[5]} .single_bit_orig_name {reg_packed_byte[5]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_packed_byte_reg[5]/Q} .original_name {reg_packed_byte[5]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[6]} .original_name {{reg_packed_byte[6]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[6]} .single_bit_orig_name {reg_packed_byte[6]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_packed_byte_reg[6]/Q} .original_name {reg_packed_byte[6]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[7]} .original_name {{reg_packed_byte[7]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[7]} .single_bit_orig_name {reg_packed_byte[7]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_packed_byte_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_packed_byte_reg[7]/Q} .original_name {reg_packed_byte[7]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[0]} .original_name {{reg_scale_a[0]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[0]} .single_bit_orig_name {reg_scale_a[0]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_a_reg[0]/Q} .original_name {reg_scale_a[0]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[1]} .original_name {{reg_scale_a[1]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[1]} .single_bit_orig_name {reg_scale_a[1]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_a_reg[1]/Q} .original_name {reg_scale_a[1]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[2]} .original_name {{reg_scale_a[2]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[2]} .single_bit_orig_name {reg_scale_a[2]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_a_reg[2]/Q} .original_name {reg_scale_a[2]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[3]} .original_name {{reg_scale_a[3]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[3]} .single_bit_orig_name {reg_scale_a[3]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_a_reg[3]/Q} .original_name {reg_scale_a[3]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[4]} .original_name {{reg_scale_a[4]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[4]} .single_bit_orig_name {reg_scale_a[4]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_a_reg[4]/Q} .original_name {reg_scale_a[4]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[5]} .original_name {{reg_scale_a[5]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[5]} .single_bit_orig_name {reg_scale_a[5]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_a_reg[5]/Q} .original_name {reg_scale_a[5]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[6]} .original_name {{reg_scale_a[6]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[6]} .single_bit_orig_name {reg_scale_a[6]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_a_reg[6]/Q} .original_name {reg_scale_a[6]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[7]} .original_name {{reg_scale_a[7]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[7]} .single_bit_orig_name {reg_scale_a[7]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_a_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_a_reg[7]/Q} .original_name {reg_scale_a[7]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[0]} .original_name {{reg_scale_b[0]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[0]} .single_bit_orig_name {reg_scale_b[0]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_b_reg[0]/Q} .original_name {reg_scale_b[0]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[1]} .original_name {{reg_scale_b[1]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[1]} .single_bit_orig_name {reg_scale_b[1]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_b_reg[1]/Q} .original_name {reg_scale_b[1]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[2]} .original_name {{reg_scale_b[2]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[2]} .single_bit_orig_name {reg_scale_b[2]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_b_reg[2]/Q} .original_name {reg_scale_b[2]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[3]} .original_name {{reg_scale_b[3]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[3]} .single_bit_orig_name {reg_scale_b[3]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_b_reg[3]/Q} .original_name {reg_scale_b[3]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[4]} .original_name {{reg_scale_b[4]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[4]} .single_bit_orig_name {reg_scale_b[4]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_b_reg[4]/Q} .original_name {reg_scale_b[4]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[5]} .original_name {{reg_scale_b[5]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[5]} .single_bit_orig_name {reg_scale_b[5]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_b_reg[5]/Q} .original_name {reg_scale_b[5]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[6]} .original_name {{reg_scale_b[6]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[6]} .single_bit_orig_name {reg_scale_b[6]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_b_reg[6]/Q} .original_name {reg_scale_b[6]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[7]} .original_name {{reg_scale_b[7]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[7]} .single_bit_orig_name {reg_scale_b[7]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_scale_b_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_scale_b_reg[7]/Q} .original_name {reg_scale_b[7]/q}
set_db -quiet inst:mac_accelerator_wrapper/reg_start_reg .original_name reg_start
set_db -quiet inst:mac_accelerator_wrapper/reg_start_reg .orig_hdl_instantiated false
set_db -quiet inst:mac_accelerator_wrapper/reg_start_reg .single_bit_orig_name reg_start
set_db -quiet inst:mac_accelerator_wrapper/reg_start_reg .gint_phase_inversion false
set_db -quiet pin:mac_accelerator_wrapper/reg_start_reg/Q .original_name reg_start/q
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[0]} .original_name {{reg_tensor_scale[0]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[0]} .single_bit_orig_name {reg_tensor_scale[0]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[0]/Q} .original_name {reg_tensor_scale[0]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[1]} .original_name {{reg_tensor_scale[1]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[1]} .single_bit_orig_name {reg_tensor_scale[1]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[1]/Q} .original_name {reg_tensor_scale[1]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[2]} .original_name {{reg_tensor_scale[2]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[2]} .single_bit_orig_name {reg_tensor_scale[2]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[2]/Q} .original_name {reg_tensor_scale[2]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[3]} .original_name {{reg_tensor_scale[3]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[3]} .single_bit_orig_name {reg_tensor_scale[3]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[3]/Q} .original_name {reg_tensor_scale[3]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[4]} .original_name {{reg_tensor_scale[4]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[4]} .single_bit_orig_name {reg_tensor_scale[4]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[4]/Q} .original_name {reg_tensor_scale[4]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[5]} .original_name {{reg_tensor_scale[5]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[5]} .single_bit_orig_name {reg_tensor_scale[5]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[5]/Q} .original_name {reg_tensor_scale[5]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[6]} .original_name {{reg_tensor_scale[6]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[6]} .single_bit_orig_name {reg_tensor_scale[6]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[6]/Q} .original_name {reg_tensor_scale[6]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[7]} .original_name {{reg_tensor_scale[7]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[7]} .single_bit_orig_name {reg_tensor_scale[7]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[7]/Q} .original_name {reg_tensor_scale[7]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[8]} .original_name {{reg_tensor_scale[8]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[8]} .single_bit_orig_name {reg_tensor_scale[8]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[8]/Q} .original_name {reg_tensor_scale[8]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[9]} .original_name {{reg_tensor_scale[9]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[9]} .single_bit_orig_name {reg_tensor_scale[9]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[9]/Q} .original_name {reg_tensor_scale[9]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[10]} .original_name {{reg_tensor_scale[10]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[10]} .single_bit_orig_name {reg_tensor_scale[10]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[10]/Q} .original_name {reg_tensor_scale[10]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[11]} .original_name {{reg_tensor_scale[11]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[11]} .single_bit_orig_name {reg_tensor_scale[11]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[11]/Q} .original_name {reg_tensor_scale[11]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[12]} .original_name {{reg_tensor_scale[12]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[12]} .single_bit_orig_name {reg_tensor_scale[12]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[12]/Q} .original_name {reg_tensor_scale[12]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[13]} .original_name {{reg_tensor_scale[13]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[13]} .single_bit_orig_name {reg_tensor_scale[13]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[13]/Q} .original_name {reg_tensor_scale[13]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[14]} .original_name {{reg_tensor_scale[14]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[14]} .single_bit_orig_name {reg_tensor_scale[14]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[14]/Q} .original_name {reg_tensor_scale[14]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[15]} .original_name {{reg_tensor_scale[15]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[15]} .single_bit_orig_name {reg_tensor_scale[15]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[15]/Q} .original_name {reg_tensor_scale[15]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[16]} .original_name {{reg_tensor_scale[16]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[16]} .single_bit_orig_name {reg_tensor_scale[16]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[16]/Q} .original_name {reg_tensor_scale[16]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[17]} .original_name {{reg_tensor_scale[17]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[17]} .single_bit_orig_name {reg_tensor_scale[17]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[17]/Q} .original_name {reg_tensor_scale[17]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[18]} .original_name {{reg_tensor_scale[18]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[18]} .single_bit_orig_name {reg_tensor_scale[18]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[18]/Q} .original_name {reg_tensor_scale[18]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[19]} .original_name {{reg_tensor_scale[19]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[19]} .single_bit_orig_name {reg_tensor_scale[19]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[19]/Q} .original_name {reg_tensor_scale[19]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[20]} .original_name {{reg_tensor_scale[20]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[20]} .single_bit_orig_name {reg_tensor_scale[20]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[20]/Q} .original_name {reg_tensor_scale[20]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[21]} .original_name {{reg_tensor_scale[21]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[21]} .single_bit_orig_name {reg_tensor_scale[21]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[21]/Q} .original_name {reg_tensor_scale[21]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[22]} .original_name {{reg_tensor_scale[22]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[22]} .single_bit_orig_name {reg_tensor_scale[22]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[22]/Q} .original_name {reg_tensor_scale[22]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[23]} .original_name {{reg_tensor_scale[23]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[23]} .single_bit_orig_name {reg_tensor_scale[23]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[23]/Q} .original_name {reg_tensor_scale[23]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[24]} .original_name {{reg_tensor_scale[24]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[24]} .single_bit_orig_name {reg_tensor_scale[24]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[24]/Q} .original_name {reg_tensor_scale[24]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[25]} .original_name {{reg_tensor_scale[25]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[25]} .single_bit_orig_name {reg_tensor_scale[25]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[25]/Q} .original_name {reg_tensor_scale[25]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[26]} .original_name {{reg_tensor_scale[26]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[26]} .single_bit_orig_name {reg_tensor_scale[26]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[26]/Q} .original_name {reg_tensor_scale[26]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[27]} .original_name {{reg_tensor_scale[27]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[27]} .single_bit_orig_name {reg_tensor_scale[27]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[27]/Q} .original_name {reg_tensor_scale[27]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[28]} .original_name {{reg_tensor_scale[28]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[28]} .single_bit_orig_name {reg_tensor_scale[28]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[28]/Q} .original_name {reg_tensor_scale[28]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[29]} .original_name {{reg_tensor_scale[29]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[29]} .single_bit_orig_name {reg_tensor_scale[29]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[29]/Q} .original_name {reg_tensor_scale[29]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[30]} .original_name {{reg_tensor_scale[30]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[30]} .single_bit_orig_name {reg_tensor_scale[30]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[30]/Q} .original_name {reg_tensor_scale[30]/q}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[31]} .original_name {{reg_tensor_scale[31]}}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[31]} .single_bit_orig_name {reg_tensor_scale[31]}
set_db -quiet {inst:mac_accelerator_wrapper/reg_tensor_scale_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/reg_tensor_scale_reg[31]/Q} .original_name {reg_tensor_scale[31]/q}
set_db -quiet {inst:mac_accelerator_wrapper/state_reg[0]} .original_name {{state[0]}}
set_db -quiet {inst:mac_accelerator_wrapper/state_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/state_reg[0]} .single_bit_orig_name {state[0]}
set_db -quiet {inst:mac_accelerator_wrapper/state_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/state_reg[0]/Q} .original_name {state[0]/q}
set_db -quiet {inst:mac_accelerator_wrapper/state_reg[1]} .original_name {{state[1]}}
set_db -quiet {inst:mac_accelerator_wrapper/state_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/state_reg[1]} .single_bit_orig_name {state[1]}
set_db -quiet {inst:mac_accelerator_wrapper/state_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/state_reg[1]/Q} .original_name {state[1]/q}
set_db -quiet inst:mac_accelerator_wrapper/u_mac_fopt24018 .seq_dup_name_count 1
set_db -quiet inst:mac_accelerator_wrapper/u_mac_fopt24019 .seq_dup_name_count 1
set_db -quiet inst:mac_accelerator_wrapper/u_mac_g37681__8428 .seq_dup_name_count 1
set_db -quiet inst:mac_accelerator_wrapper/u_mac_g41767 .seq_dup_name_count 1
set_db -quiet inst:mac_accelerator_wrapper/u_mac_g41910 .seq_dup_name_count 1
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[2]} .original_name {{u_mac/accum_out[2]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[2]} .single_bit_orig_name {u_mac/accum_out[2]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[2]/Q} .original_name {u_mac/accum_out[2]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[3]} .original_name {{u_mac/accum_out[3]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[3]} .single_bit_orig_name {u_mac/accum_out[3]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[3]/Q} .original_name {u_mac/accum_out[3]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[4]} .original_name {{u_mac/accum_out[4]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[4]} .single_bit_orig_name {u_mac/accum_out[4]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[4]/Q} .original_name {u_mac/accum_out[4]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[5]} .original_name {{u_mac/accum_out[5]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[5]} .single_bit_orig_name {u_mac/accum_out[5]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[5]/Q} .original_name {u_mac/accum_out[5]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[6]} .original_name {{u_mac/accum_out[6]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[6]} .single_bit_orig_name {u_mac/accum_out[6]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[6]/Q} .original_name {u_mac/accum_out[6]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[7]} .original_name {{u_mac/accum_out[7]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[7]} .single_bit_orig_name {u_mac/accum_out[7]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[7]/Q} .original_name {u_mac/accum_out[7]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[8]} .original_name {{u_mac/accum_out[8]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[8]} .single_bit_orig_name {u_mac/accum_out[8]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[8]/Q} .original_name {u_mac/accum_out[8]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[9]} .original_name {{u_mac/accum_out[9]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[9]} .single_bit_orig_name {u_mac/accum_out[9]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[9]/Q} .original_name {u_mac/accum_out[9]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[10]} .original_name {{u_mac/accum_out[10]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[10]} .single_bit_orig_name {u_mac/accum_out[10]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[10]/Q} .original_name {u_mac/accum_out[10]/q}
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[10]/QN} .original_name {u_mac/accum_out[10]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[11]} .original_name {{u_mac/accum_out[11]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[11]} .single_bit_orig_name {u_mac/accum_out[11]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[11]/Q} .original_name {u_mac/accum_out[11]/q}
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[11]/QN} .original_name {u_mac/accum_out[11]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[12]} .original_name {{u_mac/accum_out[12]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[12]} .single_bit_orig_name {u_mac/accum_out[12]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[12]/Q} .original_name {u_mac/accum_out[12]/q}
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[12]/QN} .original_name {u_mac/accum_out[12]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[13]} .original_name {{u_mac/accum_out[13]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[13]} .single_bit_orig_name {u_mac/accum_out[13]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[13]/Q} .original_name {u_mac/accum_out[13]/q}
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[13]/QN} .original_name {u_mac/accum_out[13]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[16]} .original_name {{u_mac/accum_out[16]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[16]} .single_bit_orig_name {u_mac/accum_out[16]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[16]/Q} .original_name {u_mac/accum_out[16]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[17]} .original_name {{u_mac/accum_out[17]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[17]} .single_bit_orig_name {u_mac/accum_out[17]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[17]/Q} .original_name {u_mac/accum_out[17]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[18]} .original_name {{u_mac/accum_out[18]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[18]} .single_bit_orig_name {u_mac/accum_out[18]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[18]/Q} .original_name {u_mac/accum_out[18]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[19]} .original_name {{u_mac/accum_out[19]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[19]} .single_bit_orig_name {u_mac/accum_out[19]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[19]/Q} .original_name {u_mac/accum_out[19]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[20]} .original_name {{u_mac/accum_out[20]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[20]} .single_bit_orig_name {u_mac/accum_out[20]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[20]/Q} .original_name {u_mac/accum_out[20]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[21]} .original_name {{u_mac/accum_out[21]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[21]} .single_bit_orig_name {u_mac/accum_out[21]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[21]/Q} .original_name {u_mac/accum_out[21]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[22]} .original_name {{u_mac/accum_out[22]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[22]} .single_bit_orig_name {u_mac/accum_out[22]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[22]/Q} .original_name {u_mac/accum_out[22]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[23]} .original_name {{u_mac/accum_out[23]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[23]} .single_bit_orig_name {u_mac/accum_out[23]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[23]/Q} .original_name {u_mac/accum_out[23]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[24]} .original_name {{u_mac/accum_out[24]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[24]} .single_bit_orig_name {u_mac/accum_out[24]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[24]/Q} .original_name {u_mac/accum_out[24]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[25]} .original_name {{u_mac/accum_out[25]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[25]} .single_bit_orig_name {u_mac/accum_out[25]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[25]/Q} .original_name {u_mac/accum_out[25]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[26]} .original_name {{u_mac/accum_out[26]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[26]} .single_bit_orig_name {u_mac/accum_out[26]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[26]/Q} .original_name {u_mac/accum_out[26]/q}
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[26]/QN} .original_name {u_mac/accum_out[26]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[27]} .original_name {{u_mac/accum_out[27]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[27]} .single_bit_orig_name {u_mac/accum_out[27]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[27]/Q} .original_name {u_mac/accum_out[27]/q}
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[27]/QN} .original_name {u_mac/accum_out[27]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[28]} .original_name {{u_mac/accum_out[28]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[28]} .single_bit_orig_name {u_mac/accum_out[28]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[28]/Q} .original_name {u_mac/accum_out[28]/q}
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[28]/QN} .original_name {u_mac/accum_out[28]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[29]} .original_name {{u_mac/accum_out[29]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[29]} .single_bit_orig_name {u_mac/accum_out[29]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[29]/Q} .original_name {u_mac/accum_out[29]/q}
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[29]/QN} .original_name {u_mac/accum_out[29]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[31]} .original_name {{u_mac/accum_out[31]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[31]} .single_bit_orig_name {u_mac/accum_out[31]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[31]/Q} .original_name {u_mac/accum_out[31]/q}
set_db -quiet inst:mac_accelerator_wrapper/u_mac_valid_out_reg .original_name u_mac/valid_out
set_db -quiet inst:mac_accelerator_wrapper/u_mac_valid_out_reg .orig_hdl_instantiated false
set_db -quiet inst:mac_accelerator_wrapper/u_mac_valid_out_reg .single_bit_orig_name u_mac/valid_out
set_db -quiet inst:mac_accelerator_wrapper/u_mac_valid_out_reg .gint_phase_inversion false
set_db -quiet pin:mac_accelerator_wrapper/u_mac_valid_out_reg/Q .original_name u_mac/valid_out/q
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[0]} .original_name {{u_mac/accum_out[0]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[0]} .single_bit_orig_name {u_mac/accum_out[0]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[0]/Q} .original_name {u_mac/accum_out[0]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[1]} .original_name {{u_mac/accum_out[1]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[1]} .single_bit_orig_name {u_mac/accum_out[1]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[1]/Q} .original_name {u_mac/accum_out[1]/q}
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[1]/QN} .original_name {u_mac/accum_out[1]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[14]} .original_name {{u_mac/accum_out[14]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[14]} .single_bit_orig_name {u_mac/accum_out[14]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[14]/Q} .original_name {u_mac/accum_out[14]/q}
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[14]/QN} .original_name {u_mac/accum_out[14]/q}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[15]} .original_name {{u_mac/accum_out[15]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[15]} .single_bit_orig_name {u_mac/accum_out[15]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[15]/Q} .original_name {u_mac/accum_out[15]/q}
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[15]/QN} .original_name {u_mac/accum_out[15]/q}
set_db -quiet inst:mac_accelerator_wrapper/u_mac_u_add01_sub_44_45_Y_u_add01_add_43_45_g3501 .seq_dup_name_count 1
set_db -quiet inst:mac_accelerator_wrapper/u_mac_u_eff_mul_30_34_g8319 .seq_dup_name_count 1
set_db -quiet inst:mac_accelerator_wrapper/u_mac_u_smul1_mul_30_34_g5360 .seq_dup_name_count 1
set_db -quiet inst:mac_accelerator_wrapper/u_mac_u_smul1_mul_30_34_g5362 .seq_dup_name_count 1
set_db -quiet inst:mac_accelerator_wrapper/reg_rst_accum_reg .original_name reg_rst_accum
set_db -quiet inst:mac_accelerator_wrapper/reg_rst_accum_reg .orig_hdl_instantiated false
set_db -quiet inst:mac_accelerator_wrapper/reg_rst_accum_reg .single_bit_orig_name reg_rst_accum
set_db -quiet inst:mac_accelerator_wrapper/reg_rst_accum_reg .gint_phase_inversion false
set_db -quiet pin:mac_accelerator_wrapper/reg_rst_accum_reg/Q .original_name reg_rst_accum/q
set_db -quiet pin:mac_accelerator_wrapper/reg_rst_accum_reg/QN .original_name reg_rst_accum/q
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[30]} .original_name {{u_mac/accum_out[30]}}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[30]} .single_bit_orig_name {u_mac/accum_out[30]}
set_db -quiet {inst:mac_accelerator_wrapper/u_mac_accum_out_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[30]/Q} .original_name {u_mac/accum_out[30]/q}
set_db -quiet {pin:mac_accelerator_wrapper/u_mac_accum_out_reg[30]/QN} .original_name {u_mac/accum_out[30]/q}
# BEGIN PMBIST SECTION
# END PMBIST SECTION
# BEGIN PHYSICAL ANNOTATION SECTION
# END PHYSICAL ANNOTATION SECTION
set_db -quiet source_verbose true
#############################################################
#####   FLOW WRITE   ########################################
##
## Written by Genus(TM) Synthesis Solution version 21.10-p002_1
## flowkit v21.10-d047_1
## Written on 21:23:57 21-Jun 2026
#############################################################
#####   Flow Definitions   ##################################

#############################################################
#####   Step Definitions   ##################################


#############################################################
#####   Attribute Definitions   #############################

if {[is_attribute flow_edit_end_steps -obj_type root]} {set_db flow_edit_end_steps {}}
if {[is_attribute flow_edit_start_steps -obj_type root]} {set_db flow_edit_start_steps {}}
if {[is_attribute flow_footer_tcl -obj_type root]} {set_db flow_footer_tcl {}}
if {[is_attribute flow_header_tcl -obj_type root]} {set_db flow_header_tcl {}}
if {[is_attribute flow_metadata -obj_type root]} {set_db flow_metadata {}}
if {[is_attribute flow_setup_config -obj_type root]} {set_db flow_setup_config {HUDDLE {!!map {}}}}
if {[is_attribute flow_step_begin_tcl -obj_type root]} {set_db flow_step_begin_tcl {}}
if {[is_attribute flow_step_check_tcl -obj_type root]} {set_db flow_step_check_tcl {}}
if {[is_attribute flow_step_end_tcl -obj_type root]} {set_db flow_step_end_tcl {}}
if {[is_attribute flow_step_order -obj_type root]} {set_db flow_step_order {}}
if {[is_attribute flow_summary_tcl -obj_type root]} {set_db flow_summary_tcl {}}
if {[is_attribute flow_template_feature_definition -obj_type root]} {set_db flow_template_feature_definition {}}
if {[is_attribute flow_template_type -obj_type root]} {set_db flow_template_type {}}
if {[is_attribute flow_template_tools -obj_type root]} {set_db flow_template_tools {}}
if {[is_attribute flow_template_version -obj_type root]} {set_db flow_template_version {}}
if {[is_attribute flow_user_templates -obj_type root]} {set_db flow_user_templates {}}


#############################################################
#####   Flow History   ######################################

if {[is_attribute flow_user_templates -obj_type root]} {set_db flow_user_templates {}}
if {[is_attribute flow_plugin_steps -obj_type root]} {set_db flow_plugin_steps {}}
if {[is_attribute flow_template_type -obj_type root]} {set_db flow_template_type {}}
if {[is_attribute flow_template_tools -obj_type root]} {set_db flow_template_tools {}}
if {[is_attribute flow_template_version -obj_type root]} {set_db flow_template_version {}}
if {[is_attribute flow_template_feature_definition -obj_type root]} {set_db flow_template_feature_definition {}}
if {[is_attribute flow_remark -obj_type root]} {set_db flow_remark {}}
if {[is_attribute flow_features -obj_type root]} {set_db flow_features {}}
if {[is_attribute flow_feature_values -obj_type root]} {set_db flow_feature_values {}}
if {[is_attribute flow_write_db_args -obj_type root]} {set_db flow_write_db_args {}}
if {[is_attribute flow_write_db_sdc -obj_type root]} {set_db flow_write_db_sdc true}
if {[is_attribute flow_write_db_common -obj_type root]} {set_db flow_write_db_common false}
if {[is_attribute flow_post_db_overwrite -obj_type root]} {set_db flow_post_db_overwrite {}}
if {[is_attribute flow_step_order -obj_type root]} {set_db flow_step_order {}}
if {[is_attribute flow_step_begin_tcl -obj_type root]} {set_db flow_step_begin_tcl {}}
if {[is_attribute flow_step_end_tcl -obj_type root]} {set_db flow_step_end_tcl {}}
if {[is_attribute flow_step_last -obj_type root]} {set_db flow_step_last {}}
if {[is_attribute flow_step_current -obj_type root]} {set_db flow_step_current {}}
if {[is_attribute flow_step_canonical_current -obj_type root]} {set_db flow_step_canonical_current {}}
if {[is_attribute flow_step_next -obj_type root]} {set_db flow_step_next {}}
if {[is_attribute flow_working_directory -obj_type root]} {set_db flow_working_directory .}
if {[is_attribute flow_branch -obj_type root]} {set_db flow_branch {}}
if {[is_attribute flow_caller_data -obj_type root]} {set_db flow_caller_data {}}
if {[is_attribute flow_metrics_snapshot_uuid -obj_type root]} {set_db flow_metrics_snapshot_uuid 4ec69ea4-8997-449e-942d-3feae6fc1e24}
if {[is_attribute flow_starting_db -obj_type root]} {set_db flow_starting_db {}}
if {[is_attribute flow_db_directory -obj_type root]} {set_db flow_db_directory dbs}
if {[is_attribute flow_report_directory -obj_type root]} {set_db flow_report_directory reports}
if {[is_attribute flow_log_directory -obj_type root]} {set_db flow_log_directory logs}
if {[is_attribute flow_mail_to -obj_type root]} {set_db flow_mail_to {}}
if {[is_attribute flow_exit_when_done -obj_type root]} {set_db flow_exit_when_done false}
if {[is_attribute flow_mail_on_error -obj_type root]} {set_db flow_mail_on_error false}
if {[is_attribute flow_summary_tcl -obj_type root]} {set_db flow_summary_tcl {}}
if {[is_attribute flow_history -obj_type root]} {set_db flow_history {}}
if {[is_attribute flow_step_last_status -obj_type root]} {set_db flow_step_last_status not_run}
if {[is_attribute flow_step_last_msg -obj_type root]} {set_db flow_step_last_msg {}}
if {[is_attribute flow_run_tag -obj_type root]} {set_db flow_run_tag {}}
if {[is_attribute flow_current_cache -obj_type root]} {set_db flow_current_cache {}}
if {[is_attribute flow_step_order_cache -obj_type root]} {set_db flow_step_order_cache {}}
if {[is_attribute flow_step_results_cache -obj_type root]} {set_db flow_step_results_cache {}}
if {[is_attribute flow_metadata -obj_type root]} {set_db flow_metadata {}}
if {[is_attribute flow_execute_in_global -obj_type root]} {set_db flow_execute_in_global true}
if {[is_attribute flow_overwrite_db -obj_type root]} {set_db flow_overwrite_db false}
if {[is_attribute flow_print_run_information -obj_type root]} {set_db flow_print_run_information false}
if {[is_attribute flow_verbose -obj_type root]} {set_db flow_verbose true}
if {[is_attribute flow_print_run_information_full -obj_type root]} {set_db flow_print_run_information_full false}
if {[is_attribute flow_header_tcl -obj_type root]} {set_db flow_header_tcl {}}
if {[is_attribute flow_footer_tcl -obj_type root]} {set_db flow_footer_tcl {}}
if {[is_attribute flow_init_header_tcl -obj_type root]} {set_db flow_init_header_tcl {}}
if {[is_attribute flow_init_footer_tcl -obj_type root]} {set_db flow_init_footer_tcl {}}
if {[is_attribute flow_edit_start_steps -obj_type root]} {set_db flow_edit_start_steps {}}
if {[is_attribute flow_edit_end_steps -obj_type root]} {set_db flow_edit_end_steps {}}
if {[is_attribute flow_step_last_number -obj_type root]} {set_db flow_step_last_number 0}
if {[is_attribute flow_autoload_applets -obj_type root]} {set_db flow_autoload_applets false}
if {[is_attribute flow_autoload_dir -obj_type root]} {set_db flow_autoload_dir error}
if {[is_attribute flow_skip_auto_db_save -obj_type root]} {set_db flow_skip_auto_db_save true}
if {[is_attribute flow_skip_auto_generate_metrics -obj_type root]} {set_db flow_skip_auto_generate_metrics false}
if {[is_attribute flow_top -obj_type root]} {set_db flow_top {}}
if {[is_attribute flow_hier_path -obj_type root]} {set_db flow_hier_path {}}
if {[is_attribute flow_schedule -obj_type root]} {set_db flow_schedule {}}
if {[is_attribute flow_step_check_tcl -obj_type root]} {set_db flow_step_check_tcl {}}
if {[is_attribute flow_script -obj_type root]} {set_db flow_script {}}
if {[is_attribute flow_yaml_script -obj_type root]} {set_db flow_yaml_script {}}
if {[is_attribute flow_cla_enabled_features -obj_type root]} {set_db flow_cla_enabled_features {}}
if {[is_attribute flow_cla_inject_tcl -obj_type root]} {set_db flow_cla_inject_tcl {}}
if {[is_attribute flow_error_message -obj_type root]} {set_db flow_error_message {}}
if {[is_attribute flow_error_errorinfo -obj_type root]} {set_db flow_error_errorinfo {}}
if {[is_attribute flow_reset_time_after_flow_init -obj_type root]} {set_db flow_reset_time_after_flow_init false}
if {[is_attribute flow_error_write_db -obj_type root]} {set_db flow_error_write_db true}
if {[is_attribute flow_advanced_metric_isolation -obj_type root]} {set_db flow_advanced_metric_isolation flow}
if {[is_attribute flow_yaml_root -obj_type root]} {set_db flow_yaml_root {}}
if {[is_attribute flow_yaml_root_dir -obj_type root]} {set_db flow_yaml_root_dir {}}
if {[is_attribute flow_setup_config -obj_type root]} {set_db flow_setup_config {HUDDLE {!!map {}}}}
if {[is_attribute flow_yamllint_exec -obj_type root]} {set_db flow_yamllint_exec yamllint}

#############################################################
#####   User Defined Attributes   ###########################

