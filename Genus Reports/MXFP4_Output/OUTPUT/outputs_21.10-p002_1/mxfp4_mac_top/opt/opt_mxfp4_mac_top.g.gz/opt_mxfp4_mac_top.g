######################################################################

# Created by Genus(TM) Synthesis Solution 21.10-p002_1 on Tue Jun 16 23:53:20 IST 2026

# This file contains the Genus script for design:mxfp4_mac_top

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path {/home/redhatacademy19/Documents/Satyam_SRIP/gsclib045_all_v4.8/gsclib045/timing /home/redhatacademy19/Documents/Satyam_SRIP/gsclib045_all_v4.8/gsclib045_hvt/timing /home/redhatacademy19/Documents/Satyam_SRIP/gsclib045_all_v4.8/gsclib045_lvt/timing}
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{PBS_Generic-Start 0 68 0.0 8.0} {to_generic 277 345 276 285} {first_condense 8 356 10 298} {PBS_Generic_Opt-Post 303 371 303.434068 311.434068} {{PBS_Generic-Postgen HBO Optimizations} 0 371 0.0 311.434068} {PBS_TechMap-Start 0 373 0.0 312.433551} {{PBS_TechMap-Premap HBO Optimizations} 0 373 0.0 312.433551} {second_condense 12 385 14 329} {reify 21 406 38 368} {global_incr_map 6 412 5 373} {{PBS_Techmap-Global Mapping} 43 416 41.90725800000001 354.34080900000004} {{PBS_TechMap-Datapath Postmap Operations} 0 416 0.9914169999999558 355.332226} {{PBS_TechMap-Postmap HBO Optimizations} 0 416 -0.008645999999998821 355.32358} {{PBS_TechMap-Postmap Clock Gating} 1 417 1.0 356.32358} {{PBS_TechMap-Postmap Cleanup} 2 419 1.9897930000000201 358.313373} {PBS_Techmap-Post_MBCI 0 419 0.0 358.313373} {incr_opt 10 431 10 392} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tinfo_tstamp_file .rs_redhatacademy19.tstamp
set_db -quiet metric_enable true
set_db -quiet script_search_path /home/redhatacademy19/Documents/Satyam_SRIP/scripts
set_db -quiet use_area_from_lef true
set_db -quiet flow_metrics_snapshot_uuid 2920bc7f-4530-4743-a8a1-b9ea62fe32a8
set_db -quiet phys_use_segment_parasitics true
set_db -quiet probabilistic_extraction true
set_db -quiet ple_correlation_factors {1.9000 2.0000}
set_db -quiet maximum_interval_of_vias inf
set_db -quiet layer_aware_buffer true
set_db -quiet ple_mode global
set_db -quiet wireload_selection none
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/PVT_1P32V_0C .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/_nominal_ .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/PVT_1P32V_0C .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/_nominal_ .tree_type balanced_tree
# BEGIN MSV SECTION
# END MSV SECTION
define_clock -name clk -domain domain_1 -period 2000.0 -divide_period 1 -rise 0 -divide_rise 1 -fall 1 -divide_fall 2 -remove -design design:mxfp4_mac_top port:mxfp4_mac_top/clk
define_cost_group -design design:mxfp4_mac_top -name clk
external_delay -accumulate -input {0.0 no_value 0.0 no_value} -clock clock:mxfp4_mac_top/clk -name create_clock_delay_domain_1_clk_R_0 port:mxfp4_mac_top/clk
set_db -quiet external_delay:mxfp4_mac_top/create_clock_delay_domain_1_clk_R_0 .clock_network_latency_included true
external_delay -accumulate -input {no_value 0.0 no_value 0.0} -clock clock:mxfp4_mac_top/clk -edge_fall -name create_clock_delay_domain_1_clk_F_0 port:mxfp4_mac_top/clk
set_db -quiet external_delay:mxfp4_mac_top/create_clock_delay_domain_1_clk_F_0 .clock_network_latency_included true
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8 port:mxfp4_mac_top/rst
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_1_1 port:mxfp4_mac_top/valid_in
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_2_1 {{port:mxfp4_mac_top/packed_byte[7]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_3_1 {{port:mxfp4_mac_top/packed_byte[6]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_4_1 {{port:mxfp4_mac_top/packed_byte[5]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_5_1 {{port:mxfp4_mac_top/packed_byte[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_6_1 {{port:mxfp4_mac_top/packed_byte[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_7_1 {{port:mxfp4_mac_top/packed_byte[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_8_1 {{port:mxfp4_mac_top/packed_byte[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_9_1 {{port:mxfp4_mac_top/packed_byte[0]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_10_1 {{port:mxfp4_mac_top/scale_code[7]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_11_1 {{port:mxfp4_mac_top/scale_code[6]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_12_1 {{port:mxfp4_mac_top/scale_code[5]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_13_1 {{port:mxfp4_mac_top/scale_code[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_14_1 {{port:mxfp4_mac_top/scale_code[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_15_1 {{port:mxfp4_mac_top/scale_code[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_16_1 {{port:mxfp4_mac_top/scale_code[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_17_1 {{port:mxfp4_mac_top/scale_code[0]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_18_1 {{port:mxfp4_mac_top/b_elem_0[31]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_19_1 {{port:mxfp4_mac_top/b_elem_0[30]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_20_1 {{port:mxfp4_mac_top/b_elem_0[29]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_21_1 {{port:mxfp4_mac_top/b_elem_0[28]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_22_1 {{port:mxfp4_mac_top/b_elem_0[27]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_23_1 {{port:mxfp4_mac_top/b_elem_0[26]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_24_1 {{port:mxfp4_mac_top/b_elem_0[25]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_25_1 {{port:mxfp4_mac_top/b_elem_0[24]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_26_1 {{port:mxfp4_mac_top/b_elem_0[23]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_27_1 {{port:mxfp4_mac_top/b_elem_0[22]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_28_1 {{port:mxfp4_mac_top/b_elem_0[21]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_29_1 {{port:mxfp4_mac_top/b_elem_0[20]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_30_1 {{port:mxfp4_mac_top/b_elem_0[19]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_31_1 {{port:mxfp4_mac_top/b_elem_0[18]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_32_1 {{port:mxfp4_mac_top/b_elem_0[17]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_33_1 {{port:mxfp4_mac_top/b_elem_0[16]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_34_1 {{port:mxfp4_mac_top/b_elem_0[15]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_35_1 {{port:mxfp4_mac_top/b_elem_0[14]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_36_1 {{port:mxfp4_mac_top/b_elem_0[13]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_37_1 {{port:mxfp4_mac_top/b_elem_0[12]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_38_1 {{port:mxfp4_mac_top/b_elem_0[11]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_39_1 {{port:mxfp4_mac_top/b_elem_0[10]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_40_1 {{port:mxfp4_mac_top/b_elem_0[9]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_41_1 {{port:mxfp4_mac_top/b_elem_0[8]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_42_1 {{port:mxfp4_mac_top/b_elem_0[7]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_43_1 {{port:mxfp4_mac_top/b_elem_0[6]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_44_1 {{port:mxfp4_mac_top/b_elem_0[5]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_45_1 {{port:mxfp4_mac_top/b_elem_0[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_46_1 {{port:mxfp4_mac_top/b_elem_0[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_47_1 {{port:mxfp4_mac_top/b_elem_0[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_48_1 {{port:mxfp4_mac_top/b_elem_0[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_49_1 {{port:mxfp4_mac_top/b_elem_0[0]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_50_1 {{port:mxfp4_mac_top/b_elem_1[31]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_51_1 {{port:mxfp4_mac_top/b_elem_1[30]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_52_1 {{port:mxfp4_mac_top/b_elem_1[29]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_53_1 {{port:mxfp4_mac_top/b_elem_1[28]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_54_1 {{port:mxfp4_mac_top/b_elem_1[27]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_55_1 {{port:mxfp4_mac_top/b_elem_1[26]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_56_1 {{port:mxfp4_mac_top/b_elem_1[25]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_57_1 {{port:mxfp4_mac_top/b_elem_1[24]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_58_1 {{port:mxfp4_mac_top/b_elem_1[23]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_59_1 {{port:mxfp4_mac_top/b_elem_1[22]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_60_1 {{port:mxfp4_mac_top/b_elem_1[21]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_61_1 {{port:mxfp4_mac_top/b_elem_1[20]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_62_1 {{port:mxfp4_mac_top/b_elem_1[19]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_63_1 {{port:mxfp4_mac_top/b_elem_1[18]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_64_1 {{port:mxfp4_mac_top/b_elem_1[17]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_65_1 {{port:mxfp4_mac_top/b_elem_1[16]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_66_1 {{port:mxfp4_mac_top/b_elem_1[15]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_67_1 {{port:mxfp4_mac_top/b_elem_1[14]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_68_1 {{port:mxfp4_mac_top/b_elem_1[13]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_69_1 {{port:mxfp4_mac_top/b_elem_1[12]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_70_1 {{port:mxfp4_mac_top/b_elem_1[11]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_71_1 {{port:mxfp4_mac_top/b_elem_1[10]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_72_1 {{port:mxfp4_mac_top/b_elem_1[9]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_73_1 {{port:mxfp4_mac_top/b_elem_1[8]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_74_1 {{port:mxfp4_mac_top/b_elem_1[7]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_75_1 {{port:mxfp4_mac_top/b_elem_1[6]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_76_1 {{port:mxfp4_mac_top/b_elem_1[5]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_77_1 {{port:mxfp4_mac_top/b_elem_1[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_78_1 {{port:mxfp4_mac_top/b_elem_1[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_79_1 {{port:mxfp4_mac_top/b_elem_1[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_80_1 {{port:mxfp4_mac_top/b_elem_1[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_8_81_1 {{port:mxfp4_mac_top/b_elem_1[0]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9 {{port:mxfp4_mac_top/accum_out[31]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_81_1 {{port:mxfp4_mac_top/accum_out[30]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_82_1 {{port:mxfp4_mac_top/accum_out[29]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_83_1 {{port:mxfp4_mac_top/accum_out[28]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_84_1 {{port:mxfp4_mac_top/accum_out[27]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_85_1 {{port:mxfp4_mac_top/accum_out[26]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_86_1 {{port:mxfp4_mac_top/accum_out[25]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_87_1 {{port:mxfp4_mac_top/accum_out[24]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_88_1 {{port:mxfp4_mac_top/accum_out[23]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_89_1 {{port:mxfp4_mac_top/accum_out[22]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_90_1 {{port:mxfp4_mac_top/accum_out[21]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_91_1 {{port:mxfp4_mac_top/accum_out[20]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_92_1 {{port:mxfp4_mac_top/accum_out[19]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_93_1 {{port:mxfp4_mac_top/accum_out[18]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_94_1 {{port:mxfp4_mac_top/accum_out[17]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_95_1 {{port:mxfp4_mac_top/accum_out[16]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_96_1 {{port:mxfp4_mac_top/accum_out[15]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_97_1 {{port:mxfp4_mac_top/accum_out[14]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_98_1 {{port:mxfp4_mac_top/accum_out[13]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_99_1 {{port:mxfp4_mac_top/accum_out[12]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_100_1 {{port:mxfp4_mac_top/accum_out[11]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_101_1 {{port:mxfp4_mac_top/accum_out[10]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_102_1 {{port:mxfp4_mac_top/accum_out[9]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_103_1 {{port:mxfp4_mac_top/accum_out[8]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_104_1 {{port:mxfp4_mac_top/accum_out[7]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_105_1 {{port:mxfp4_mac_top/accum_out[6]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_106_1 {{port:mxfp4_mac_top/accum_out[5]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_107_1 {{port:mxfp4_mac_top/accum_out[4]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_108_1 {{port:mxfp4_mac_top/accum_out[3]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_109_1 {{port:mxfp4_mac_top/accum_out[2]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_110_1 {{port:mxfp4_mac_top/accum_out[1]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_111_1 {{port:mxfp4_mac_top/accum_out[0]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:mxfp4_mac_top/clk -name mac_unit.sdc_line_9_112_1 port:mxfp4_mac_top/valid_out
path_group -paths [specify_paths -to clock:mxfp4_mac_top/clk]  -name clk -group cost_group:mxfp4_mac_top/clk -user_priority -1047552
path_disable -paths [specify_paths -lenient -from port:mxfp4_mac_top/rst]  -name mac_unit.sdc_line_12 -user_priority -770048
set_db -quiet exception:mxfp4_mac_top/mac_unit.sdc_line_12 .sdc_filename_linenumber {{/home/redhatacademy19/Documents/Satyam_SRIP/genus/mac_unit.sdc 12}}
# BEGIN DFT SECTION
set_db -quiet dft_scan_style muxed_scan
set_db -quiet dft_scanbit_waveform_analysis false
# END DFT SECTION
set_db -quiet design:mxfp4_mac_top .seq_reason_deleted_internal {}
set_db -quiet design:mxfp4_mac_top .qos_by_stage {{to_generic {wns -11111111} {tns -111111111} {vep -111111111} {area 30700} {cell_count 10760} {utilization  0.00} {runtime 277 345 276 285} }{first_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 23800} {cell_count 8832} {utilization  0.00} {runtime 8 356 10 298} }{second_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 23108} {cell_count 8571} {utilization  0.00} {runtime 12 385 14 329} }{reify {wns -34} {tns 1001} {vep 31} {area 20681} {cell_count 6403} {utilization  0.00} {runtime 21 406 38 368} }{global_incr_map {wns -30} {tns 858} {vep 31} {area 14417} {cell_count 5049} {utilization  0.00} {runtime 6 412 5 373} }{incr_opt {wns 214748365} {tns 0} {vep 0} {area 13278} {cell_count 4694} {utilization  0.00} {runtime 10 431 10 392} }}
set_db -quiet design:mxfp4_mac_top .seq_mbci_coverage 0.0
set_db -quiet design:mxfp4_mac_top .hdl_user_name mxfp4_mac_top
set_db -quiet design:mxfp4_mac_top .hdl_filelist {{default -v2001 {SYNTHESIS} {/home/redhatacademy19/Documents/Satyam_SRIP/rtl/common/nibble_extractor.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/common/e2m1_decoder.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/common/fp32_mul.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/common/fp32_add.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/mxfp4/e8m0_decoder.v /home/redhatacademy19/Documents/Satyam_SRIP/rtl/mxfp4/mxfp4_mac_top.v} {/home/redhatacademy19/Documents/Satyam_SRIP/rtl} {}}}
set_db -quiet design:mxfp4_mac_top .verification_directory fv/mxfp4_mac_top
set_db -quiet design:mxfp4_mac_top .lp_clock_gating_max_flops inf
set_db -quiet design:mxfp4_mac_top .arch_filename /home/redhatacademy19/Documents/Satyam_SRIP/rtl/mxfp4/mxfp4_mac_top.v
set_db -quiet design:mxfp4_mac_top .entity_filename /home/redhatacademy19/Documents/Satyam_SRIP/rtl/mxfp4/mxfp4_mac_top.v
set_db -quiet port:mxfp4_mac_top/clk .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mxfp4_mac_top/clk .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mxfp4_mac_top/clk .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mxfp4_mac_top/clk .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mxfp4_mac_top/clk .original_name clk
set_db -quiet port:mxfp4_mac_top/rst .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mxfp4_mac_top/rst .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mxfp4_mac_top/rst .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mxfp4_mac_top/rst .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mxfp4_mac_top/rst .original_name rst
set_db -quiet port:mxfp4_mac_top/valid_in .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mxfp4_mac_top/valid_in .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mxfp4_mac_top/valid_in .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mxfp4_mac_top/valid_in .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet port:mxfp4_mac_top/valid_in .original_name valid_in
set_db -quiet {port:mxfp4_mac_top/packed_byte[7]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[7]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[7]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[7]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[7]} .original_name {packed_byte[7]}
set_db -quiet {port:mxfp4_mac_top/packed_byte[6]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[6]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[6]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[6]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[6]} .original_name {packed_byte[6]}
set_db -quiet {port:mxfp4_mac_top/packed_byte[5]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[5]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[5]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[5]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[5]} .original_name {packed_byte[5]}
set_db -quiet {port:mxfp4_mac_top/packed_byte[4]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[4]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[4]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[4]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[4]} .original_name {packed_byte[4]}
set_db -quiet {port:mxfp4_mac_top/packed_byte[3]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[3]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[3]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[3]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[3]} .original_name {packed_byte[3]}
set_db -quiet {port:mxfp4_mac_top/packed_byte[2]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[2]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[2]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[2]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[2]} .original_name {packed_byte[2]}
set_db -quiet {port:mxfp4_mac_top/packed_byte[1]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[1]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[1]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[1]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[1]} .original_name {packed_byte[1]}
set_db -quiet {port:mxfp4_mac_top/packed_byte[0]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[0]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[0]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[0]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/packed_byte[0]} .original_name {packed_byte[0]}
set_db -quiet {port:mxfp4_mac_top/scale_code[7]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[7]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[7]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[7]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[7]} .original_name {scale_code[7]}
set_db -quiet {port:mxfp4_mac_top/scale_code[6]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[6]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[6]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[6]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[6]} .original_name {scale_code[6]}
set_db -quiet {port:mxfp4_mac_top/scale_code[5]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[5]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[5]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[5]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[5]} .original_name {scale_code[5]}
set_db -quiet {port:mxfp4_mac_top/scale_code[4]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[4]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[4]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[4]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[4]} .original_name {scale_code[4]}
set_db -quiet {port:mxfp4_mac_top/scale_code[3]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[3]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[3]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[3]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[3]} .original_name {scale_code[3]}
set_db -quiet {port:mxfp4_mac_top/scale_code[2]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[2]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[2]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[2]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[2]} .original_name {scale_code[2]}
set_db -quiet {port:mxfp4_mac_top/scale_code[1]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[1]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[1]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[1]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[1]} .original_name {scale_code[1]}
set_db -quiet {port:mxfp4_mac_top/scale_code[0]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[0]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[0]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[0]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/scale_code[0]} .original_name {scale_code[0]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[31]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[31]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[31]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[31]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[31]} .original_name {b_elem_0[31]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[30]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[30]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[30]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[30]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[30]} .original_name {b_elem_0[30]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[29]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[29]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[29]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[29]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[29]} .original_name {b_elem_0[29]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[28]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[28]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[28]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[28]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[28]} .original_name {b_elem_0[28]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[27]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[27]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[27]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[27]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[27]} .original_name {b_elem_0[27]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[26]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[26]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[26]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[26]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[26]} .original_name {b_elem_0[26]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[25]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[25]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[25]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[25]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[25]} .original_name {b_elem_0[25]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[24]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[24]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[24]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[24]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[24]} .original_name {b_elem_0[24]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[23]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[23]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[23]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[23]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[23]} .original_name {b_elem_0[23]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[22]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[22]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[22]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[22]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[22]} .original_name {b_elem_0[22]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[21]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[21]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[21]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[21]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[21]} .original_name {b_elem_0[21]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[20]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[20]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[20]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[20]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[20]} .original_name {b_elem_0[20]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[19]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[19]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[19]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[19]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[19]} .original_name {b_elem_0[19]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[18]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[18]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[18]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[18]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[18]} .original_name {b_elem_0[18]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[17]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[17]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[17]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[17]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[17]} .original_name {b_elem_0[17]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[16]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[16]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[16]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[16]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[16]} .original_name {b_elem_0[16]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[15]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[15]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[15]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[15]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[15]} .original_name {b_elem_0[15]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[14]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[14]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[14]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[14]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[14]} .original_name {b_elem_0[14]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[13]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[13]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[13]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[13]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[13]} .original_name {b_elem_0[13]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[12]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[12]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[12]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[12]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[12]} .original_name {b_elem_0[12]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[11]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[11]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[11]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[11]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[11]} .original_name {b_elem_0[11]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[10]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[10]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[10]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[10]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[10]} .original_name {b_elem_0[10]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[9]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[9]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[9]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[9]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[9]} .original_name {b_elem_0[9]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[8]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[8]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[8]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[8]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[8]} .original_name {b_elem_0[8]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[7]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[7]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[7]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[7]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[7]} .original_name {b_elem_0[7]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[6]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[6]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[6]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[6]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[6]} .original_name {b_elem_0[6]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[5]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[5]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[5]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[5]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[5]} .original_name {b_elem_0[5]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[4]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[4]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[4]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[4]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[4]} .original_name {b_elem_0[4]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[3]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[3]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[3]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[3]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[3]} .original_name {b_elem_0[3]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[2]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[2]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[2]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[2]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[2]} .original_name {b_elem_0[2]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[1]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[1]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[1]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[1]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[1]} .original_name {b_elem_0[1]}
set_db -quiet {port:mxfp4_mac_top/b_elem_0[0]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[0]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[0]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[0]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_0[0]} .original_name {b_elem_0[0]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[31]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[31]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[31]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[31]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[31]} .original_name {b_elem_1[31]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[30]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[30]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[30]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[30]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[30]} .original_name {b_elem_1[30]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[29]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[29]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[29]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[29]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[29]} .original_name {b_elem_1[29]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[28]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[28]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[28]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[28]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[28]} .original_name {b_elem_1[28]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[27]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[27]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[27]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[27]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[27]} .original_name {b_elem_1[27]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[26]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[26]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[26]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[26]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[26]} .original_name {b_elem_1[26]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[25]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[25]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[25]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[25]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[25]} .original_name {b_elem_1[25]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[24]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[24]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[24]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[24]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[24]} .original_name {b_elem_1[24]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[23]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[23]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[23]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[23]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[23]} .original_name {b_elem_1[23]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[22]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[22]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[22]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[22]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[22]} .original_name {b_elem_1[22]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[21]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[21]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[21]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[21]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[21]} .original_name {b_elem_1[21]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[20]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[20]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[20]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[20]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[20]} .original_name {b_elem_1[20]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[19]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[19]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[19]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[19]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[19]} .original_name {b_elem_1[19]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[18]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[18]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[18]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[18]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[18]} .original_name {b_elem_1[18]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[17]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[17]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[17]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[17]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[17]} .original_name {b_elem_1[17]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[16]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[16]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[16]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[16]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[16]} .original_name {b_elem_1[16]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[15]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[15]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[15]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[15]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[15]} .original_name {b_elem_1[15]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[14]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[14]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[14]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[14]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[14]} .original_name {b_elem_1[14]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[13]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[13]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[13]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[13]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[13]} .original_name {b_elem_1[13]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[12]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[12]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[12]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[12]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[12]} .original_name {b_elem_1[12]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[11]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[11]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[11]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[11]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[11]} .original_name {b_elem_1[11]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[10]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[10]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[10]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[10]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[10]} .original_name {b_elem_1[10]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[9]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[9]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[9]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[9]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[9]} .original_name {b_elem_1[9]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[8]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[8]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[8]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[8]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[8]} .original_name {b_elem_1[8]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[7]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[7]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[7]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[7]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[7]} .original_name {b_elem_1[7]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[6]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[6]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[6]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[6]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[6]} .original_name {b_elem_1[6]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[5]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[5]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[5]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[5]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[5]} .original_name {b_elem_1[5]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[4]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[4]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[4]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[4]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[4]} .original_name {b_elem_1[4]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[3]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[3]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[3]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[3]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[3]} .original_name {b_elem_1[3]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[2]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[2]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[2]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[2]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[2]} .original_name {b_elem_1[2]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[1]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[1]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[1]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[1]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[1]} .original_name {b_elem_1[1]}
set_db -quiet {port:mxfp4_mac_top/b_elem_1[0]} .driver_pin_rise_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[0]} .driver_pin_fall_min lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[0]} .driver_pin_rise_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[0]} .driver_pin_fall_max lib_pin:default_emulate_libset_max/fast_vdd1v2/INVX2/Y
set_db -quiet {port:mxfp4_mac_top/b_elem_1[0]} .original_name {b_elem_1[0]}
set_db -quiet {port:mxfp4_mac_top/accum_out[31]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[31]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[31]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[31]} .original_name {accum_out[31]}
set_db -quiet {port:mxfp4_mac_top/accum_out[31]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[30]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[30]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[30]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[30]} .original_name {accum_out[30]}
set_db -quiet {port:mxfp4_mac_top/accum_out[30]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[29]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[29]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[29]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[29]} .original_name {accum_out[29]}
set_db -quiet {port:mxfp4_mac_top/accum_out[29]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[28]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[28]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[28]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[28]} .original_name {accum_out[28]}
set_db -quiet {port:mxfp4_mac_top/accum_out[28]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[27]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[27]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[27]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[27]} .original_name {accum_out[27]}
set_db -quiet {port:mxfp4_mac_top/accum_out[27]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[26]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[26]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[26]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[26]} .original_name {accum_out[26]}
set_db -quiet {port:mxfp4_mac_top/accum_out[26]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[25]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[25]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[25]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[25]} .original_name {accum_out[25]}
set_db -quiet {port:mxfp4_mac_top/accum_out[25]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[24]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[24]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[24]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[24]} .original_name {accum_out[24]}
set_db -quiet {port:mxfp4_mac_top/accum_out[24]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[23]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[23]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[23]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[23]} .original_name {accum_out[23]}
set_db -quiet {port:mxfp4_mac_top/accum_out[23]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[22]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[22]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[22]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[22]} .original_name {accum_out[22]}
set_db -quiet {port:mxfp4_mac_top/accum_out[22]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[21]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[21]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[21]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[21]} .original_name {accum_out[21]}
set_db -quiet {port:mxfp4_mac_top/accum_out[21]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[20]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[20]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[20]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[20]} .original_name {accum_out[20]}
set_db -quiet {port:mxfp4_mac_top/accum_out[20]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[19]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[19]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[19]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[19]} .original_name {accum_out[19]}
set_db -quiet {port:mxfp4_mac_top/accum_out[19]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[18]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[18]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[18]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[18]} .original_name {accum_out[18]}
set_db -quiet {port:mxfp4_mac_top/accum_out[18]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[17]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[17]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[17]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[17]} .original_name {accum_out[17]}
set_db -quiet {port:mxfp4_mac_top/accum_out[17]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[16]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[16]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[16]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[16]} .original_name {accum_out[16]}
set_db -quiet {port:mxfp4_mac_top/accum_out[16]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[15]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[15]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[15]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[15]} .original_name {accum_out[15]}
set_db -quiet {port:mxfp4_mac_top/accum_out[15]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[14]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[14]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[14]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[14]} .original_name {accum_out[14]}
set_db -quiet {port:mxfp4_mac_top/accum_out[14]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[13]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[13]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[13]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[13]} .original_name {accum_out[13]}
set_db -quiet {port:mxfp4_mac_top/accum_out[13]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[12]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[12]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[12]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[12]} .original_name {accum_out[12]}
set_db -quiet {port:mxfp4_mac_top/accum_out[12]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[11]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[11]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[11]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[11]} .original_name {accum_out[11]}
set_db -quiet {port:mxfp4_mac_top/accum_out[11]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[10]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[10]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[10]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[10]} .original_name {accum_out[10]}
set_db -quiet {port:mxfp4_mac_top/accum_out[10]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[9]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[9]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[9]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[9]} .original_name {accum_out[9]}
set_db -quiet {port:mxfp4_mac_top/accum_out[9]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[8]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[8]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[8]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[8]} .original_name {accum_out[8]}
set_db -quiet {port:mxfp4_mac_top/accum_out[8]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[7]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[7]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[7]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[7]} .original_name {accum_out[7]}
set_db -quiet {port:mxfp4_mac_top/accum_out[7]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[6]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[6]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[6]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[6]} .original_name {accum_out[6]}
set_db -quiet {port:mxfp4_mac_top/accum_out[6]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[5]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[5]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[5]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[5]} .original_name {accum_out[5]}
set_db -quiet {port:mxfp4_mac_top/accum_out[5]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[4]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[4]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[4]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[4]} .original_name {accum_out[4]}
set_db -quiet {port:mxfp4_mac_top/accum_out[4]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[3]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[3]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[3]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[3]} .original_name {accum_out[3]}
set_db -quiet {port:mxfp4_mac_top/accum_out[3]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[2]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[2]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[2]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[2]} .original_name {accum_out[2]}
set_db -quiet {port:mxfp4_mac_top/accum_out[2]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[1]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[1]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[1]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[1]} .original_name {accum_out[1]}
set_db -quiet {port:mxfp4_mac_top/accum_out[1]} .external_pin_cap {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[0]} .external_pin_cap_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[0]} .external_capacitance_max {10.0 10.0}
set_db -quiet {port:mxfp4_mac_top/accum_out[0]} .external_capacitance_min 10.0
set_db -quiet {port:mxfp4_mac_top/accum_out[0]} .original_name {accum_out[0]}
set_db -quiet {port:mxfp4_mac_top/accum_out[0]} .external_pin_cap {10.0 10.0}
set_db -quiet port:mxfp4_mac_top/valid_out .external_pin_cap_min 10.0
set_db -quiet port:mxfp4_mac_top/valid_out .external_capacitance_max {10.0 10.0}
set_db -quiet port:mxfp4_mac_top/valid_out .external_capacitance_min 10.0
set_db -quiet port:mxfp4_mac_top/valid_out .original_name valid_out
set_db -quiet port:mxfp4_mac_top/valid_out .external_pin_cap {10.0 10.0}
set_db -quiet inst:mxfp4_mac_top/valid_out_reg .original_name valid_out
set_db -quiet inst:mxfp4_mac_top/valid_out_reg .orig_hdl_instantiated false
set_db -quiet inst:mxfp4_mac_top/valid_out_reg .single_bit_orig_name valid_out
set_db -quiet inst:mxfp4_mac_top/valid_out_reg .gint_phase_inversion false
set_db -quiet pin:mxfp4_mac_top/valid_out_reg/Q .original_name valid_out/q
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[1]} .original_name {{accum_out[1]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[1]} .single_bit_orig_name {accum_out[1]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[1]/Q} .original_name {accum_out[1]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[3]} .original_name {{accum_out[3]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[3]} .single_bit_orig_name {accum_out[3]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[3]/Q} .original_name {accum_out[3]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[4]} .original_name {{accum_out[4]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[4]} .single_bit_orig_name {accum_out[4]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[4]/Q} .original_name {accum_out[4]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[5]} .original_name {{accum_out[5]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[5]} .single_bit_orig_name {accum_out[5]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[5]/Q} .original_name {accum_out[5]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[6]} .original_name {{accum_out[6]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[6]} .single_bit_orig_name {accum_out[6]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[6]/Q} .original_name {accum_out[6]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[9]} .original_name {{accum_out[9]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[9]} .single_bit_orig_name {accum_out[9]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[9]/Q} .original_name {accum_out[9]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[12]} .original_name {{accum_out[12]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[12]} .single_bit_orig_name {accum_out[12]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[12]/Q} .original_name {accum_out[12]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[15]} .original_name {{accum_out[15]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[15]} .single_bit_orig_name {accum_out[15]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[15]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[15]/Q} .original_name {accum_out[15]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[16]} .original_name {{accum_out[16]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[16]} .single_bit_orig_name {accum_out[16]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[16]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[16]/Q} .original_name {accum_out[16]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[20]} .original_name {{accum_out[20]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[20]} .single_bit_orig_name {accum_out[20]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[20]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[20]/Q} .original_name {accum_out[20]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[21]} .original_name {{accum_out[21]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[21]} .single_bit_orig_name {accum_out[21]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[21]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[21]/Q} .original_name {accum_out[21]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[23]} .original_name {{accum_out[23]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[23]} .single_bit_orig_name {accum_out[23]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[23]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[23]/Q} .original_name {accum_out[23]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[24]} .original_name {{accum_out[24]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[24]} .single_bit_orig_name {accum_out[24]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[24]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[24]/Q} .original_name {accum_out[24]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[25]} .original_name {{accum_out[25]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[25]} .single_bit_orig_name {accum_out[25]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[25]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[25]/Q} .original_name {accum_out[25]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[26]} .original_name {{accum_out[26]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[26]} .single_bit_orig_name {accum_out[26]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[26]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[26]/Q} .original_name {accum_out[26]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[27]} .original_name {{accum_out[27]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[27]} .single_bit_orig_name {accum_out[27]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[27]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[27]/Q} .original_name {accum_out[27]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[28]} .original_name {{accum_out[28]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[28]} .single_bit_orig_name {accum_out[28]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[28]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[28]/Q} .original_name {accum_out[28]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[29]} .original_name {{accum_out[29]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[29]} .single_bit_orig_name {accum_out[29]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[29]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[29]/Q} .original_name {accum_out[29]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[30]} .original_name {{accum_out[30]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[30]} .single_bit_orig_name {accum_out[30]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[30]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[30]/Q} .original_name {accum_out[30]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[31]} .original_name {{accum_out[31]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[31]} .single_bit_orig_name {accum_out[31]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[31]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[31]/Q} .original_name {accum_out[31]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[0]} .original_name {{accum_out[0]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[0]} .single_bit_orig_name {accum_out[0]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[0]/Q} .original_name {accum_out[0]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[7]} .original_name {{accum_out[7]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[7]} .single_bit_orig_name {accum_out[7]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[7]/Q} .original_name {accum_out[7]/q}
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[7]/QN} .original_name {accum_out[7]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[14]} .original_name {{accum_out[14]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[14]} .single_bit_orig_name {accum_out[14]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[14]/Q} .original_name {accum_out[14]/q}
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[14]/QN} .original_name {accum_out[14]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[13]} .original_name {{accum_out[13]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[13]} .single_bit_orig_name {accum_out[13]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[13]/Q} .original_name {accum_out[13]/q}
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[13]/QN} .original_name {accum_out[13]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[17]} .original_name {{accum_out[17]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[17]} .single_bit_orig_name {accum_out[17]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[17]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[17]/Q} .original_name {accum_out[17]/q}
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[17]/QN} .original_name {accum_out[17]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[8]} .original_name {{accum_out[8]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[8]} .single_bit_orig_name {accum_out[8]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[8]/Q} .original_name {accum_out[8]/q}
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[8]/QN} .original_name {accum_out[8]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[10]} .original_name {{accum_out[10]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[10]} .single_bit_orig_name {accum_out[10]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[10]/Q} .original_name {accum_out[10]/q}
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[10]/QN} .original_name {accum_out[10]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[11]} .original_name {{accum_out[11]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[11]} .single_bit_orig_name {accum_out[11]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[11]/Q} .original_name {accum_out[11]/q}
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[11]/QN} .original_name {accum_out[11]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[2]} .original_name {{accum_out[2]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[2]} .single_bit_orig_name {accum_out[2]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[2]/Q} .original_name {accum_out[2]/q}
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[2]/QN} .original_name {accum_out[2]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[19]} .original_name {{accum_out[19]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[19]} .single_bit_orig_name {accum_out[19]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[19]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[19]/Q} .original_name {accum_out[19]/q}
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[19]/QN} .original_name {accum_out[19]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[22]} .original_name {{accum_out[22]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[22]} .single_bit_orig_name {accum_out[22]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[22]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[22]/Q} .original_name {accum_out[22]/q}
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[22]/QN} .original_name {accum_out[22]/q}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[18]} .original_name {{accum_out[18]}}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[18]} .single_bit_orig_name {accum_out[18]}
set_db -quiet {inst:mxfp4_mac_top/accum_out_reg[18]} .gint_phase_inversion false
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[18]/Q} .original_name {accum_out[18]/q}
set_db -quiet {pin:mxfp4_mac_top/accum_out_reg[18]/QN} .original_name {accum_out[18]/q}
# BEGIN PMBIST SECTION
# END PMBIST SECTION
# BEGIN PHYSICAL ANNOTATION SECTION
# END PHYSICAL ANNOTATION SECTION
set_db -quiet source_verbose true
#############################################################
#####   FLOW WRITE   ########################################
##
## Written by Genus(TM) Synthesis Solution version 21.10-p002_1
## flowkit v21.10-d047_1
## Written on 23:53:21 16-Jun 2026
#############################################################
#####   Flow Definitions   ##################################

#############################################################
#####   Step Definitions   ##################################


#############################################################
#####   Attribute Definitions   #############################

if {[is_attribute flow_edit_end_steps -obj_type root]} {set_db flow_edit_end_steps {}}
if {[is_attribute flow_edit_start_steps -obj_type root]} {set_db flow_edit_start_steps {}}
if {[is_attribute flow_footer_tcl -obj_type root]} {set_db flow_footer_tcl {}}
if {[is_attribute flow_header_tcl -obj_type root]} {set_db flow_header_tcl {}}
if {[is_attribute flow_metadata -obj_type root]} {set_db flow_metadata {}}
if {[is_attribute flow_setup_config -obj_type root]} {set_db flow_setup_config {HUDDLE {!!map {}}}}
if {[is_attribute flow_step_begin_tcl -obj_type root]} {set_db flow_step_begin_tcl {}}
if {[is_attribute flow_step_check_tcl -obj_type root]} {set_db flow_step_check_tcl {}}
if {[is_attribute flow_step_end_tcl -obj_type root]} {set_db flow_step_end_tcl {}}
if {[is_attribute flow_step_order -obj_type root]} {set_db flow_step_order {}}
if {[is_attribute flow_summary_tcl -obj_type root]} {set_db flow_summary_tcl {}}
if {[is_attribute flow_template_feature_definition -obj_type root]} {set_db flow_template_feature_definition {}}
if {[is_attribute flow_template_type -obj_type root]} {set_db flow_template_type {}}
if {[is_attribute flow_template_tools -obj_type root]} {set_db flow_template_tools {}}
if {[is_attribute flow_template_version -obj_type root]} {set_db flow_template_version {}}
if {[is_attribute flow_user_templates -obj_type root]} {set_db flow_user_templates {}}


#############################################################
#####   Flow History   ######################################

if {[is_attribute flow_user_templates -obj_type root]} {set_db flow_user_templates {}}
if {[is_attribute flow_plugin_steps -obj_type root]} {set_db flow_plugin_steps {}}
if {[is_attribute flow_template_type -obj_type root]} {set_db flow_template_type {}}
if {[is_attribute flow_template_tools -obj_type root]} {set_db flow_template_tools {}}
if {[is_attribute flow_template_version -obj_type root]} {set_db flow_template_version {}}
if {[is_attribute flow_template_feature_definition -obj_type root]} {set_db flow_template_feature_definition {}}
if {[is_attribute flow_remark -obj_type root]} {set_db flow_remark {}}
if {[is_attribute flow_features -obj_type root]} {set_db flow_features {}}
if {[is_attribute flow_feature_values -obj_type root]} {set_db flow_feature_values {}}
if {[is_attribute flow_write_db_args -obj_type root]} {set_db flow_write_db_args {}}
if {[is_attribute flow_write_db_sdc -obj_type root]} {set_db flow_write_db_sdc true}
if {[is_attribute flow_write_db_common -obj_type root]} {set_db flow_write_db_common false}
if {[is_attribute flow_post_db_overwrite -obj_type root]} {set_db flow_post_db_overwrite {}}
if {[is_attribute flow_step_order -obj_type root]} {set_db flow_step_order {}}
if {[is_attribute flow_step_begin_tcl -obj_type root]} {set_db flow_step_begin_tcl {}}
if {[is_attribute flow_step_end_tcl -obj_type root]} {set_db flow_step_end_tcl {}}
if {[is_attribute flow_step_last -obj_type root]} {set_db flow_step_last {}}
if {[is_attribute flow_step_current -obj_type root]} {set_db flow_step_current {}}
if {[is_attribute flow_step_canonical_current -obj_type root]} {set_db flow_step_canonical_current {}}
if {[is_attribute flow_step_next -obj_type root]} {set_db flow_step_next {}}
if {[is_attribute flow_working_directory -obj_type root]} {set_db flow_working_directory .}
if {[is_attribute flow_branch -obj_type root]} {set_db flow_branch {}}
if {[is_attribute flow_caller_data -obj_type root]} {set_db flow_caller_data {}}
if {[is_attribute flow_metrics_snapshot_uuid -obj_type root]} {set_db flow_metrics_snapshot_uuid 2920bc7f-4530-4743-a8a1-b9ea62fe32a8}
if {[is_attribute flow_starting_db -obj_type root]} {set_db flow_starting_db {}}
if {[is_attribute flow_db_directory -obj_type root]} {set_db flow_db_directory dbs}
if {[is_attribute flow_report_directory -obj_type root]} {set_db flow_report_directory reports}
if {[is_attribute flow_log_directory -obj_type root]} {set_db flow_log_directory logs}
if {[is_attribute flow_mail_to -obj_type root]} {set_db flow_mail_to {}}
if {[is_attribute flow_exit_when_done -obj_type root]} {set_db flow_exit_when_done false}
if {[is_attribute flow_mail_on_error -obj_type root]} {set_db flow_mail_on_error false}
if {[is_attribute flow_summary_tcl -obj_type root]} {set_db flow_summary_tcl {}}
if {[is_attribute flow_history -obj_type root]} {set_db flow_history {}}
if {[is_attribute flow_step_last_status -obj_type root]} {set_db flow_step_last_status not_run}
if {[is_attribute flow_step_last_msg -obj_type root]} {set_db flow_step_last_msg {}}
if {[is_attribute flow_run_tag -obj_type root]} {set_db flow_run_tag {}}
if {[is_attribute flow_current_cache -obj_type root]} {set_db flow_current_cache {}}
if {[is_attribute flow_step_order_cache -obj_type root]} {set_db flow_step_order_cache {}}
if {[is_attribute flow_step_results_cache -obj_type root]} {set_db flow_step_results_cache {}}
if {[is_attribute flow_metadata -obj_type root]} {set_db flow_metadata {}}
if {[is_attribute flow_execute_in_global -obj_type root]} {set_db flow_execute_in_global true}
if {[is_attribute flow_overwrite_db -obj_type root]} {set_db flow_overwrite_db false}
if {[is_attribute flow_print_run_information -obj_type root]} {set_db flow_print_run_information false}
if {[is_attribute flow_verbose -obj_type root]} {set_db flow_verbose true}
if {[is_attribute flow_print_run_information_full -obj_type root]} {set_db flow_print_run_information_full false}
if {[is_attribute flow_header_tcl -obj_type root]} {set_db flow_header_tcl {}}
if {[is_attribute flow_footer_tcl -obj_type root]} {set_db flow_footer_tcl {}}
if {[is_attribute flow_init_header_tcl -obj_type root]} {set_db flow_init_header_tcl {}}
if {[is_attribute flow_init_footer_tcl -obj_type root]} {set_db flow_init_footer_tcl {}}
if {[is_attribute flow_edit_start_steps -obj_type root]} {set_db flow_edit_start_steps {}}
if {[is_attribute flow_edit_end_steps -obj_type root]} {set_db flow_edit_end_steps {}}
if {[is_attribute flow_step_last_number -obj_type root]} {set_db flow_step_last_number 0}
if {[is_attribute flow_autoload_applets -obj_type root]} {set_db flow_autoload_applets false}
if {[is_attribute flow_autoload_dir -obj_type root]} {set_db flow_autoload_dir error}
if {[is_attribute flow_skip_auto_db_save -obj_type root]} {set_db flow_skip_auto_db_save true}
if {[is_attribute flow_skip_auto_generate_metrics -obj_type root]} {set_db flow_skip_auto_generate_metrics false}
if {[is_attribute flow_top -obj_type root]} {set_db flow_top {}}
if {[is_attribute flow_hier_path -obj_type root]} {set_db flow_hier_path {}}
if {[is_attribute flow_schedule -obj_type root]} {set_db flow_schedule {}}
if {[is_attribute flow_step_check_tcl -obj_type root]} {set_db flow_step_check_tcl {}}
if {[is_attribute flow_script -obj_type root]} {set_db flow_script {}}
if {[is_attribute flow_yaml_script -obj_type root]} {set_db flow_yaml_script {}}
if {[is_attribute flow_cla_enabled_features -obj_type root]} {set_db flow_cla_enabled_features {}}
if {[is_attribute flow_cla_inject_tcl -obj_type root]} {set_db flow_cla_inject_tcl {}}
if {[is_attribute flow_error_message -obj_type root]} {set_db flow_error_message {}}
if {[is_attribute flow_error_errorinfo -obj_type root]} {set_db flow_error_errorinfo {}}
if {[is_attribute flow_reset_time_after_flow_init -obj_type root]} {set_db flow_reset_time_after_flow_init false}
if {[is_attribute flow_error_write_db -obj_type root]} {set_db flow_error_write_db true}
if {[is_attribute flow_advanced_metric_isolation -obj_type root]} {set_db flow_advanced_metric_isolation flow}
if {[is_attribute flow_yaml_root -obj_type root]} {set_db flow_yaml_root {}}
if {[is_attribute flow_yaml_root_dir -obj_type root]} {set_db flow_yaml_root_dir {}}
if {[is_attribute flow_setup_config -obj_type root]} {set_db flow_setup_config {HUDDLE {!!map {}}}}
if {[is_attribute flow_yamllint_exec -obj_type root]} {set_db flow_yamllint_exec yamllint}

#############################################################
#####   User Defined Attributes   ###########################

